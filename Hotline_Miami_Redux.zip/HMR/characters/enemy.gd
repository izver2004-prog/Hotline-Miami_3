extends CharacterBody2D
## Враг: состояния idle/patrol/chase/search/stun/dead, зрение (конус+LOS), слух, A* поиск пути.

var level
var kind := {}
var kind_id := ""
var hp := 1
var state := "idle"
var dir := Vector2.RIGHT
var cd := 0.0
var react := 0.0
var windup := 0.0
var stun := 0.0
var path := PackedVector2Array()
var path_t := 0.0
var lost_t := 0.0
var alert_pos := Vector2.ZERO
var patrol_t := 0.0
var patrol_target := Vector2.ZERO
var idle_turn := 0.0
var anim_t := 0.0
var frame := 0
var vis: Node2D
var body: Sprite2D
var wspr: Sprite2D
var weapon := {}

func setup(lv, kid: String) -> void:
	level = lv
	kind_id = kid
	kind = Data.ENEMIES[kid]
	hp = int(kind["hp"])
	weapon = Data.weapon(kind["w"])
	collision_layer = 4
	collision_mask = 1
	var cs := CollisionShape2D.new()
	var c := CircleShape2D.new()
	c.radius = 9.0
	cs.shape = c
	add_child(cs)
	vis = Node2D.new()
	add_child(vis)
	body = Sprite2D.new()
	body.scale = Vector2(2, 2)
	body.texture = Art.enemy_tex(kid, 0)
	vis.add_child(body)
	wspr = Sprite2D.new()
	wspr.scale = Vector2(2, 2)
	wspr.position = Vector2(14, 0)
	wspr.texture = Art.weapon_tex(kind["w"])
	vis.add_child(wspr)
	dir = Vector2.from_angle(randf() * TAU)
	state = "patrol" if kind["beh"] == "patrol" else "idle"
	patrol_target = global_position
	idle_turn = randf_range(1.5, 4.0)

func hear(pos: Vector2) -> void:
	if state == "dead" or state == "chase":
		return
	state = "search"
	alert_pos = pos
	lost_t = 5.0
	path_t = 0.0
	dir = (pos - global_position).normalized()

func _can_see() -> bool:
	var p = level.player
	if not p.alive:
		return false
	var to: Vector2 = p.global_position - global_position
	var d := to.length()
	var sight := float(kind["sight"]) * float(p.mods.get("stealth", 1.0))
	if d > sight:
		return false
	var in_cone: bool = absf(angle_difference(dir.angle(), to.angle())) < deg_to_rad(float(kind["fov"]) * 0.5)
	if not in_cone and d > 48.0:
		return false
	return level.has_los(global_position, p.global_position)

func _follow(target: Vector2, spd: float, dt: float) -> void:
	path_t -= dt
	if path_t <= 0.0 or path.is_empty():
		path = level.find_path(global_position, target)
		path_t = 0.35
	while path.size() > 1 and global_position.distance_to(path[0]) < 8.0:
		path.remove_at(0)
	var tgt: Vector2 = path[0] if path.size() > 0 else target
	var v := (tgt - global_position).normalized() * spd
	velocity = v
	move_and_slide()
	for i in get_slide_collision_count():
		var c = get_slide_collision(i).get_collider()
		if c and c.has_method("open"):
			c.open(false)
	if v.length() > 1.0:
		dir = dir.lerp(v.normalized(), 0.25).normalized()
		anim_t += dt
		if anim_t > 0.16:
			anim_t = 0.0
			frame = 1 - frame
			body.texture = Art.enemy_tex(kind_id, frame)

func _physics_process(dt: float) -> void:
	if state == "dead":
		return
	cd = maxf(0.0, cd - dt)
	if stun > 0.0:
		stun -= dt
		vis.rotation += dt * 6.0
		return
	var p = level.player
	var seen := _can_see()
	if seen:
		if state != "chase":
			react = float(kind.get("react", 0.35)) if kind.has("react") else 0.35
		state = "chase"
		alert_pos = p.global_position
		lost_t = 4.0
		level.make_noise(global_position, 0.0)
	var spd := float(kind["spd"])
	match state:
		"idle":
			idle_turn -= dt
			if idle_turn <= 0.0:
				dir = Vector2.from_angle(randf() * TAU)
				idle_turn = randf_range(1.5, 4.0)
		"patrol":
			patrol_t -= dt
			if patrol_t <= 0.0 or global_position.distance_to(patrol_target) < 12.0:
				patrol_target = global_position + Vector2.from_angle(randf() * TAU) * randf_range(60, 200)
				patrol_t = 3.0
				path_t = 0.0
			_follow(patrol_target, spd * 0.55, dt)
		"search":
			lost_t -= dt
			if global_position.distance_to(alert_pos) > 14.0:
				_follow(alert_pos, spd * 0.8, dt)
			if lost_t <= 0.0:
				state = "patrol" if kind["beh"] == "patrol" else "idle"
		"chase":
			if not seen:
				lost_t -= dt
				if lost_t <= 0.0:
					state = "search"
					lost_t = 3.0
			_chase(p, seen, spd, dt)
	vis.rotation = dir.angle()

func _chase(p, seen: bool, spd: float, dt: float) -> void:
	var to: Vector2 = alert_pos - global_position
	var rng := float(kind["rng"])
	if rng <= 0.0:
		# ближний бой
		if windup > 0.0:
			windup -= dt
			if windup <= 0.0:
				if p.alive and p.global_position.distance_to(global_position) < 44.0:
					p.hit(1, (p.global_position - global_position).normalized(), "melee")
				Audio.play("swing", 0.6)
			return
		if seen and to.length() < 30.0:
			dir = to.normalized()
			if cd <= 0.0:
				windup = 0.22
				cd = float(weapon["rate"]) + 0.5
			return
		_follow(alert_pos, spd * 1.15, dt)
	else:
		if seen and to.length() < rng:
			dir = to.normalized()
			react -= dt
			if react <= 0.0 and cd <= 0.0:
				_shoot(p)
			return
		_follow(alert_pos, spd * 1.05, dt)

func _shoot(p) -> void:
	cd = float(weapon["rate"]) * 2.2 + randf_range(0.0, 0.3)
	var spread := deg_to_rad(float(weapon["spread"]) * 1.1 + 4.0)
	for i in int(weapon["pellets"]):
		level.spawn_bullet({"pos": global_position + dir * 18.0, "ang": dir.angle() + randf_range(-spread, spread),
			"spd": minf(float(weapon["speed"]), 460.0), "dmg": 1, "own": false, "col": Color(1.0, 0.3, 0.4),
			"rng": float(weapon["rng"]), "pierce": 0, "src": self})
	Audio.play(str(weapon["snd"]), 0.6)
	level.make_noise(global_position, float(weapon["noise"]) * 0.6)

func hit(dmg: int, hdir: Vector2, src: String) -> void:
	if state == "dead":
		return
	if dmg <= 0:
		if stun > 0.0:
			die(src, hdir)
		else:
			stun = 2.5
			Audio.play("hit")
		return
	if stun > 0.0 and (src == "melee"):
		die(src, hdir)
		return
	hp -= dmg
	level.add_blood(global_position, hdir, false)
	if hp <= 0:
		die(src, hdir)
	else:
		stun = 0.35
		Audio.play("hit")

func die(src: String, hdir: Vector2) -> void:
	state = "dead"
	collision_layer = 0
	collision_mask = 0
	wspr.visible = false
	body.modulate = Color(0.55, 0.45, 0.5)
	vis.rotation = hdir.angle() + randf_range(-0.6, 0.6)
	z_index = -1
	Audio.play("kill")
	level.add_blood(global_position, hdir, true)
	level.shake_cam(4.0)
	var w: Dictionary = weapon
	if w["type"] == "gun":
		level.spawn_pickup(kind["w"], global_position + hdir * 10.0, int(w["mag"]) / 2)
	elif w["type"] == "melee":
		level.spawn_pickup(kind["w"], global_position + hdir * 10.0, 0)
	level.on_enemy_killed(self, src)
