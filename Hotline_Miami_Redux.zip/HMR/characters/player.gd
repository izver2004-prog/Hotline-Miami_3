extends CharacterBody2D
## Игрок: движение, бег, прицел, ближний бой, стрельба, броски, подбор, 2 слота оружия, маски.

var level
var slots := [{"id": "", "ammo": 0, "reserve": 0}, {"id": "", "ammo": 0, "reserve": 0}]
var active := 0
var aim_angle := 0.0
var cd := 0.0
var reload_t := 0.0
var alive := true
var armor := 0
var invuln := 0.0
var anim_t := 0.0
var frame := 0
var mods := {}
var vis: Node2D
var body: Sprite2D
var wspr: Sprite2D
var slash_t := 0.0
var slash_reach := 40.0
var stats_shots := 0
var stats_hits := 0
var mask_id := "fox"
var last_dir := Vector2.RIGHT

func setup(lv, mid: String, start_weapon: String) -> void:
	level = lv
	mask_id = mid
	mods = Data.mask_mods(mid)
	armor = int(mods.get("armor", 0))
	collision_layer = 2
	collision_mask = 1
	add_to_group("player")
	var cs := CollisionShape2D.new()
	var c := CircleShape2D.new()
	c.radius = 9.0
	cs.shape = c
	add_child(cs)
	vis = Node2D.new()
	add_child(vis)
	body = Sprite2D.new()
	body.scale = Vector2(2, 2)
	body.texture = Art.player_tex(mid, 0)
	vis.add_child(body)
	wspr = Sprite2D.new()
	wspr.scale = Vector2(2, 2)
	wspr.position = Vector2(14, 0)
	vis.add_child(wspr)
	Inp.pressed.connect(_on_pressed)
	if start_weapon != "":
		give(start_weapon)
	_refresh_weapon()

func cur() -> Dictionary:
	return slots[active]

func give(id: String, ammo: int = -1, reserve: int = -1) -> void:
	var w: Dictionary = Data.weapon(id)
	var s := {"id": id, "ammo": 0, "reserve": 0}
	var am := float(mods.get("ammo", 1.0))
	if w["type"] == "gun":
		s["ammo"] = ammo if ammo >= 0 else int(float(w["mag"]) * am)
		s["reserve"] = reserve if reserve >= 0 else int(float(w["reserve"]) * am)
	elif w["type"] == "throw":
		s["ammo"] = ammo if ammo >= 0 else int(w["mag"])
	if slots[active]["id"] == "":
		slots[active] = s
	elif slots[1 - active]["id"] == "":
		active = 1 - active
		slots[active] = s
	else:
		slots[active] = s
	Game.found_weapon(id)
	_refresh_weapon()

func _refresh_weapon() -> void:
	var id: String = cur()["id"]
	wspr.visible = id != ""
	if id != "":
		wspr.texture = Art.weapon_tex(id)

func _on_pressed(a: String) -> void:
	if not alive or get_tree().paused:
		return
	match a:
		"melee": melee_attack("fists", true)
		"interact": _interact()
		"pickup": _pickup()
		"swap": _swap()
		"reload": start_reload()

func _nearest(group: String, maxd: float):
	var best = null
	var bd := maxd
	for n in get_tree().get_nodes_in_group(group):
		var d: float = n.global_position.distance_to(global_position)
		if d < bd:
			bd = d
			best = n
	return best

func _interact() -> void:
	var d = _nearest("doors", 48.0)
	if d:
		d.toggle()

func _pickup() -> void:
	var p = _nearest("pickups", 38.0 * float(mods.get("pickup", 1.0)))
	if p == null:
		start_reload()
		return
	var old: Dictionary = cur().duplicate()
	var need_drop: bool = old["id"] != "" and slots[1 - active]["id"] != ""
	var id: String = p.id
	var am: int = p.ammo
	p.queue_free()
	if need_drop:
		level.spawn_pickup(old["id"], global_position, int(old["ammo"]))
	give(id, am)
	Audio.play("pickup")

func _swap() -> void:
	if slots[1 - active]["id"] != "" or cur()["id"] != "":
		active = 1 - active
		reload_t = 0.0
		Audio.play("swap")
		_refresh_weapon()

func start_reload() -> void:
	var s: Dictionary = cur()
	if s["id"] == "" or reload_t > 0.0:
		return
	var w: Dictionary = Data.weapon(s["id"])
	if w["type"] != "gun" or s["reserve"] <= 0 or s["ammo"] >= int(float(w["mag"]) * float(mods.get("ammo", 1.0))):
		return
	reload_t = float(w["reload"]) * float(mods.get("reload", 1.0))
	Audio.play("reload")

func _finish_reload() -> void:
	var s: Dictionary = cur()
	var w: Dictionary = Data.weapon(s["id"])
	var mag := int(float(w["mag"]) * float(mods.get("ammo", 1.0)))
	var take: int = mini(mag - int(s["ammo"]), int(s["reserve"]))
	s["ammo"] += take
	s["reserve"] -= take

func _update_aim(mv: Vector2, dt: float) -> void:
	var dir := Vector2.ZERO
	if Inp.touch_aim_active:
		var wp: Vector2 = get_viewport().get_canvas_transform().affine_inverse() * Inp.touch_aim_pos
		dir = wp - global_position
	elif not Inp.use_touch:
		dir = get_global_mouse_position() - global_position
	elif mv.length() > 0.2:
		dir = mv
	if Inp.aim_lock:
		var t = _closest_enemy(PI, 460.0)
		if t:
			dir = t.global_position - global_position
	if dir.length() > 4.0:
		var target := dir.angle()
		aim_angle = target if not Inp.use_touch else lerp_angle(aim_angle, target, minf(1.0, dt * 18.0))

func _closest_enemy(max_ang: float, max_dist: float):
	var best = null
	var bd := 1e9
	for e in level.enemies:
		if not is_instance_valid(e) or e.state == "dead":
			continue
		var to: Vector2 = e.global_position - global_position
		var d := to.length()
		if d > max_dist or absf(angle_difference(aim_angle, to.angle())) > max_ang:
			continue
		if not level.has_los(global_position, e.global_position):
			continue
		if d < bd:
			bd = d
			best = e
	return best

func _assisted_angle() -> float:
	if Settings.data["aim_assist"] and Inp.use_touch:
		var e = _closest_enemy(deg_to_rad(float(Settings.data["assist_angle"])), 480.0)
		if e:
			return (e.global_position - global_position).angle()
	return aim_angle

func _physics_process(dt: float) -> void:
	if not alive:
		return
	cd = maxf(0.0, cd - dt)
	invuln = maxf(0.0, invuln - dt)
	if slash_t > 0.0:
		slash_t -= dt
		queue_redraw()
	var mv: Vector2 = Inp.get_move()
	var spd := 150.0 * float(mods.get("speed", 1.0))
	if Inp.run:
		spd *= 1.35 * float(mods.get("run", 1.0))
	velocity = mv * spd
	move_and_slide()
	for i in get_slide_collision_count():
		var c = get_slide_collision(i).get_collider()
		if c and c.has_method("open"):
			c.open(true)
	if mv.length() > 0.1:
		last_dir = mv
		anim_t += dt * float(Settings.data["anim_speed"])
		if anim_t > 0.14:
			anim_t = 0.0
			frame = 1 - frame
			body.texture = Art.player_tex(mask_id, frame)
			Audio.step()
	_update_aim(mv, dt)
	vis.rotation = aim_angle
	if reload_t > 0.0:
		reload_t -= dt
		if reload_t <= 0.0:
			_finish_reload()
	if Inp.attack:
		try_attack()

func try_attack() -> void:
	if cd > 0.0 or reload_t > 0.0 or not alive:
		return
	var s: Dictionary = cur()
	if s["id"] == "":
		melee_attack("fists", false)
		return
	var w: Dictionary = Data.weapon(s["id"])
	match w["type"]:
		"melee":
			melee_attack(s["id"], false)
		"gun":
			if s["ammo"] <= 0:
				if s["reserve"] > 0:
					start_reload()
				else:
					_throw_item(w, s, true)
				return
			_fire(w, s)
		"throw":
			_throw_item(w, s, false)

func melee_attack(id: String, force_fists: bool) -> void:
	if cd > 0.0 or not alive:
		return
	if force_fists:
		id = "fists"
	var w: Dictionary = Data.weapon(id)
	cd = float(w["rate"]) * float(mods.get("rate", 1.0))
	slash_t = 0.14
	slash_reach = float(w["rng"]) * float(mods.get("reach", 1.0))
	Audio.play("swing")
	var half := deg_to_rad(95.0 if "wide" in str(w["fx"]) else 62.0)
	var dmg := int(w["dmg"]) + int(mods.get("melee_bonus", 0)) if int(w["dmg"]) > 0 else 0
	var hit_any := false
	for e in level.enemies:
		if not is_instance_valid(e) or e.state == "dead":
			continue
		var to: Vector2 = e.global_position - global_position
		if to.length() <= slash_reach + 10.0 and absf(angle_difference(aim_angle, to.angle())) < half:
			if level.has_los(global_position, e.global_position):
				e.hit(dmg, to.normalized(), "melee")
				hit_any = true
				stats_hits += 1
	for d in get_tree().get_nodes_in_group("doors"):
		if not d.is_open and d.global_position.distance_to(global_position) < slash_reach + 14.0:
			d.open(true)
	if hit_any:
		Audio.play("hit")
		level.shake_cam(3.0)
	level.make_noise(global_position, 80.0)
	if Settings.data["vibration"] and hit_any:
		Input.vibrate_handheld(20)

func _fire(w: Dictionary, s: Dictionary) -> void:
	s["ammo"] -= 1
	stats_shots += 1
	cd = float(w["rate"]) * float(mods.get("rate", 1.0))
	var spread := deg_to_rad(float(w["spread"])) * float(mods.get("accuracy", 1.0))
	var base := _assisted_angle()
	var pierce := int(mods.get("pierce", 0)) + (1 if "pierce" in str(w["fx"]) else 0)
	for i in int(w["pellets"]):
		var a := base + randf_range(-spread, spread)
		level.spawn_bullet({"pos": global_position + Vector2.from_angle(base) * 18.0, "ang": a,
			"spd": float(w["speed"]) * float(mods.get("bspeed", 1.0)), "dmg": int(w["dmg"]), "own": true,
			"col": Color(1.0, 0.9, 0.4), "rng": float(w["rng"]), "pierce": pierce, "src": self})
	if not ("silent" in str(w["fx"]) or mods.has("silent")):
		level.make_noise(global_position, float(w["noise"]))
	Audio.play(str(w["snd"]), 0.9)
	level.shake_cam(2.5)
	if Settings.data["vibration"]:
		Input.vibrate_handheld(12)
	if s["ammo"] <= 0 and s["reserve"] > 0:
		start_reload()

func _throw_item(w: Dictionary, s: Dictionary, empty_gun: bool) -> void:
	cd = float(w["rate"])
	var spd := 560.0 if empty_gun else float(w["speed"]) * float(mods.get("throw", 1.0))
	var fx := str(w["fx"])
	level.spawn_bullet({"pos": global_position + Vector2.from_angle(aim_angle) * 16.0, "ang": _assisted_angle(),
		"spd": spd, "dmg": 1 if empty_gun else int(w["dmg"]), "own": true, "col": Color.WHITE,
		"rng": 300.0 if empty_gun else float(w["rng"]), "pierce": 0, "tex": s["id"], "explode": "explode" in fx,
		"glass": "glass" in fx, "src": self})
	Audio.play("swing")
	if empty_gun or s["ammo"] <= 1:
		slots[active] = {"id": "", "ammo": 0, "reserve": 0}
		_refresh_weapon()
	else:
		s["ammo"] -= 1
	if not empty_gun and not ("silent" in fx):
		level.make_noise(global_position, 150.0)

func hit(_dmg: int, dir: Vector2, _src: String) -> void:
	if not alive or invuln > 0.0 or level.state == "done":
		return
	if armor > 0:
		armor -= 1
		invuln = 1.0
		level.shake_cam(8.0)
		level.add_blood(global_position, dir, false)
		Audio.play("hit")
		return
	alive = false
	wspr.visible = false
	body.modulate = Color(0.6, 0.5, 0.5)
	vis.rotation = dir.angle() + PI
	z_index = -1
	level.add_blood(global_position, dir, true)
	level.on_player_died()

func _draw() -> void:
	if slash_t > 0.0:
		var a := slash_t / 0.14
		draw_arc(Vector2.ZERO, slash_reach, aim_angle - 1.0, aim_angle + 1.0, 14, Color(1, 1, 1, a), 3.0)
