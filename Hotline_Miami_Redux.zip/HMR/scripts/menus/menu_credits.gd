extends "res://scripts/screen.gd"

func build() -> void:
	var body := page(Settings.L("АВТОРЫ", "CREDITS"))
	body.add_child(UI.lbl("Hotline Miami Redux", 40, UI.CYAN))
	body.add_child(UI.lbl(Settings.L("Оригинальная игра в духе Hotline Miami. Весь код, графика и звуки созданы специально для проекта.", "An original game inspired by Hotline Miami. All code, art and sounds are made for this project."), 26))
	body.add_child(UI.lbl("Godot Engine 4 / GDScript", 26, UI.YEL))
	body.add_child(UI.lbl(Settings.L("Музыку добавляйте в папку music/ (см. README).", "Add your music to the music/ folder (see README)."), 24, UI.PINK))
