extends "res://scripts/screen.gd"

func build() -> void:
	var body := page(Settings.L("СТАТИСТИКА", "STATISTICS"))
	var s: Dictionary = Game.save["stats"]
	var rows := [
		["Убийств", "Kills", "kills"], ["Смертей", "Deaths", "deaths"], ["Пройдено уровней", "Levels cleared", "levels"],
		["Рангов S", "S ranks", "rank_s"], ["Макс. комбо", "Max combo", "max_combo"], ["Выстрелов", "Shots", "shots"],
		["Убийств в ближнем бою", "Melee kills", "melee_kills"], ["Убийств броском", "Throw kills", "throw_kills"],
	]
	for r in rows:
		body.add_child(UI.lbl("%s: %d" % [Settings.L(r[0], r[1]), int(s.get(r[2], 0))], 30))
	body.add_child(UI.lbl("%s: %d" % [Settings.L("Масок открыто", "Masks unlocked"), Game.save["masks"].size()], 30, UI.CYAN))
	body.add_child(UI.lbl("%s: %d" % [Settings.L("Оружия найдено", "Weapons found"), Game.save["weapons"].size()], 30, UI.CYAN))
	body.add_child(UI.lbl("%s: %d мин" % [Settings.L("Время игры", "Playtime"), int(float(s.get("playtime", 0.0)) / 60.0)], 30, UI.YEL))
	body.add_child(UI.lbl(Settings.L("Рекорды:", "Records:"), 32, UI.PINK))
	for path in Game.save["done"]:
		var d: Dictionary = Game.save["done"][path]
		body.add_child(UI.lbl("%s  —  %s  %d" % [Game.level_meta(path).get("name", path), d.get("rank", "-"), int(d.get("best", 0))], 24))
	body.add_child(UI.btn(Settings.L("Сбросить прогресс", "Reset progress"), _reset, UI.PINK, 400.0))

func _reset() -> void:
	Game.reset_progress()
	get_tree().reload_current_scene()
