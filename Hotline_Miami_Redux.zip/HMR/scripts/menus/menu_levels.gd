extends "res://scripts/screen.gd"

static var chapter_idx := 0
var grid_holder: VBoxContainer

func build() -> void:
	var body := page(Settings.L("ВЫБОР УРОВНЯ", "LEVEL SELECT"))
	if Game.chapters.is_empty():
		body.add_child(UI.lbl(Settings.L("Уровни не найдены (папка levels/).", "No levels found (levels/ folder)."), 28))
		return
	var tabs := HBoxContainer.new()
	body.add_child(tabs)
	for i in Game.chapters.size():
		tabs.add_child(UI.btn(Game.chapters[i]["name"], _pick_chapter.bind(i), UI.CYAN if i == chapter_idx else UI.PINK, 160.0))
	chapter_idx = clampi(chapter_idx, 0, Game.chapters.size() - 1)
	var grid := GridContainer.new()
	grid.columns = 3 if get_viewport_rect().size.x > 900.0 else 2
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	body.add_child(grid)
	var ch: Dictionary = Game.chapters[chapter_idx]
	for li in ch["levels"].size():
		var path: String = ch["levels"][li]
		var m := Game.level_meta(path)
		var d: Dictionary = Game.save["done"].get(path, {})
		var txt := "%d. %s" % [li + 1, m.get("name", "?")]
		if d.is_empty():
			txt += "\n" + Settings.L("не пройден", "not cleared")
		else:
			txt += "\n%s  %d" % [d.get("rank", "-"), int(d.get("best", 0))]
		var unlocked := Game.is_unlocked(chapter_idx, li)
		var b := UI.btn(txt if unlocked else Settings.L("Закрыто", "Locked"), func(): Game.start_level(path), UI.PINK, 260.0)
		b.custom_minimum_size.y = 96
		b.disabled = not unlocked
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(b)

func _pick_chapter(i: int) -> void:
	chapter_idx = i
	get_tree().reload_current_scene()
