extends "res://scripts/screen.gd"
## Редактор сенсорного управления: перетаскивайте кнопки, выберите кнопку и меняйте размер/прозрачность.

const TouchScript := preload("res://ui/touch_controls.gd")

var tc: Control
var sel_label: Label
var size_s: HSlider
var alpha_s: HSlider

func build() -> void:
	tc = Control.new()
	tc.set_script(TouchScript)
	tc.edit_mode = true
	add_child(tc)
	tc.selected_changed.connect(_on_selected)
	var p := UI.panel(UI.PINK)
	p.set_anchors_preset(Control.PRESET_CENTER_TOP)
	p.offset_left = -330.0
	p.offset_right = 330.0
	p.offset_top = 10.0
	add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	p.add_child(v)
	sel_label = UI.lbl(Settings.L("Перетащите кнопку или коснитесь её", "Drag a button or tap it"), 22, UI.YEL)
	v.add_child(sel_label)
	var h1 := HBoxContainer.new()
	h1.add_child(UI.lbl(Settings.L("Размер", "Size"), 20))
	size_s = HSlider.new()
	size_s.min_value = 60.0
	size_s.max_value = 280.0
	size_s.step = 2.0
	size_s.custom_minimum_size = Vector2(420, 40)
	size_s.value_changed.connect(_on_size)
	h1.add_child(size_s)
	v.add_child(h1)
	var h2 := HBoxContainer.new()
	h2.add_child(UI.lbl(Settings.L("Прозрачность", "Opacity"), 20))
	alpha_s = HSlider.new()
	alpha_s.min_value = 0.15
	alpha_s.max_value = 1.0
	alpha_s.step = 0.05
	alpha_s.custom_minimum_size = Vector2(360, 40)
	alpha_s.value_changed.connect(_on_alpha)
	h2.add_child(alpha_s)
	v.add_child(h2)
	var h3 := HBoxContainer.new()
	h3.add_theme_constant_override("separation", 8)
	h3.add_child(UI.btn(Settings.L("Сброс", "Reset"), _reset, UI.PINK))
	h3.add_child(UI.btn(Settings.L("Готово", "Done"), func(): go("res://scenes/settings.tscn"), UI.CYAN))
	v.add_child(h3)

func _on_selected(n: String) -> void:
	sel_label.text = n.to_upper()
	size_s.set_value_no_signal(float(Settings.controls[n]["size"]))
	alpha_s.set_value_no_signal(float(Settings.controls[n]["alpha"]))

func _on_size(v: float) -> void:
	if tc.selected != "":
		Settings.controls[tc.selected]["size"] = v
		tc.queue_redraw()

func _on_alpha(v: float) -> void:
	if tc.selected != "":
		Settings.controls[tc.selected]["alpha"] = v
		tc.queue_redraw()

func _reset() -> void:
	Settings.reset_controls()
	tc.selected = ""
	tc.queue_redraw()
