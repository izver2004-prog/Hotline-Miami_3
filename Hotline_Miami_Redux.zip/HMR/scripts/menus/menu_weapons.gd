extends "res://scripts/screen.gd"

var icon: TextureRect
var info: VBoxContainer

func build() -> void:
	var body := page(Settings.L("ОРУЖИЕ", "WEAPONS"))
	var wide := get_viewport_rect().size.x > 900.0
	var split: BoxContainer = HBoxContainer.new() if wide else VBoxContainer.new()
	split.add_theme_constant_override("separation", 20)
	body.add_child(split)
	var pv := VBoxContainer.new()
	pv.custom_minimum_size = Vector2(380, 0)
	var pan := UI.panel(UI.CYAN)
	pan.add_child(pv)
	icon = TextureRect.new()
	icon.custom_minimum_size = Vector2(200, 200)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	pv.add_child(icon)
	info = VBoxContainer.new()
	pv.add_child(info)
	split.add_child(pan)
	var grid := GridContainer.new()
	grid.columns = 3 if wide else 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	split.add_child(grid)
	for id in Data.weapon_order:
		var found: bool = Game.save["weapons"].has(id)
		var w: Dictionary = Data.weapon(id)
		var b := UI.btn((w["ru"] if Settings.data["language"] == "ru" else w["en"]) if found else "???", _show.bind(id), UI.CYAN if found else UI.PINK, 150.0)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(b)
	_show("pistol")

func _show(id: String) -> void:
	var found: bool = Game.save["weapons"].has(id)
	var w: Dictionary = Data.weapon(id)
	icon.texture = Art.weapon_tex(id)
	icon.modulate = Color.WHITE if found else Color(0.15, 0.15, 0.2)
	for c in info.get_children():
		c.queue_free()
	if not found:
		info.add_child(UI.lbl(Settings.L("Найди это оружие на уровне.", "Find this weapon in a level."), 22, UI.PINK))
		return
	info.add_child(UI.lbl(w["ru"] if Settings.data["language"] == "ru" else w["en"], 34, UI.YEL))
	info.add_child(UI.lbl(w["desc"], 22))
	var type_ru: String = {"melee": "Ближний бой", "gun": "Огнестрельное", "throw": "Метательное"}[w["type"]]
	var txt := "%s: %s\n%s: %d\n%s: %.2f с" % [Settings.L("Тип", "Type"), type_ru, Settings.L("Урон", "Damage"), w["dmg"], Settings.L("Темп", "Rate"), w["rate"]]
	if w["type"] == "gun":
		txt += "\n%s: %d / %d\n%s: %d" % [Settings.L("Магазин/запас", "Mag/Reserve"), w["mag"], w["reserve"], Settings.L("Дальность", "Range"), w["rng"]]
	elif w["type"] == "melee":
		txt += "\n%s: %d" % [Settings.L("Дальность", "Reach"), w["rng"]]
	else:
		txt += "\n%s: %d" % [Settings.L("Штук", "Count"), w["mag"]]
	info.add_child(UI.lbl(txt, 22, UI.CYAN))
