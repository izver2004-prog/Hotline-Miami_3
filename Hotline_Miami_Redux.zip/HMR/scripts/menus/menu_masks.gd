extends "res://scripts/screen.gd"

var icon: TextureRect
var info: VBoxContainer
var sel_btn: Button
var current := ""

func build() -> void:
	var body := page(Settings.L("МАСКИ", "MASKS"))
	var wide := get_viewport_rect().size.x > 900.0
	var split: BoxContainer = HBoxContainer.new() if wide else VBoxContainer.new()
	split.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	split.add_theme_constant_override("separation", 20)
	body.add_child(split)
	# предпросмотр
	var pv := VBoxContainer.new()
	pv.custom_minimum_size = Vector2(380, 0)
	var pan := UI.panel(UI.CYAN)
	pan.add_child(pv)
	icon = TextureRect.new()
	icon.custom_minimum_size = Vector2(240, 240)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	pv.add_child(icon)
	info = VBoxContainer.new()
	pv.add_child(info)
	split.add_child(pan)
	# список
	var grid := GridContainer.new()
	grid.columns = 3 if wide else 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	split.add_child(grid)
	for id in Data.masks_order:
		var unlocked: bool = Game.save["masks"].has(id)
		var b := UI.btn(Data.mask(id)["ru"] if unlocked else "???", _show.bind(id), UI.CYAN if unlocked else UI.PINK, 150.0)
		b.icon = Art.mask_icon(id) if unlocked else null
		b.expand_icon = true
		b.add_theme_constant_override("icon_max_width", 40)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(b)
	_show(Game.save.get("mask", "fox"))

func _show(id: String) -> void:
	current = id
	var m: Dictionary = Data.mask(id)
	var unlocked: bool = Game.save["masks"].has(id)
	icon.texture = Art.mask_icon(id)
	icon.modulate = Color.WHITE if unlocked else Color(0.15, 0.15, 0.2)
	for c in info.get_children():
		c.queue_free()
	info.add_child(UI.lbl(m["ru"] if Settings.data["language"] == "ru" else m["en"], 34, UI.YEL))
	if unlocked:
		info.add_child(UI.lbl(m["desc"], 22))
		info.add_child(UI.lbl(Settings.L("Способность: ", "Ability: ") + m["ab"], 22, UI.CYAN))
		var chosen: bool = Game.save.get("mask", "fox") == id
		var b := UI.btn(Settings.L("Выбрана", "Selected") if chosen else Settings.L("Выбрать", "Select"), _choose.bind(id), UI.PINK)
		b.disabled = chosen
		info.add_child(b)
	else:
		info.add_child(UI.lbl(Settings.L("Условие: ", "Unlock: ") + Data.unlock_text(m["unlock"]), 22, UI.PINK))
		var p := str(m["unlock"]).split(":")
		info.add_child(UI.lbl("%d / %s" % [int(Game.stat(p[0])), p[1]], 22))

func _choose(id: String) -> void:
	Game.save["mask"] = id
	Game.write_save()
	_show(id)
