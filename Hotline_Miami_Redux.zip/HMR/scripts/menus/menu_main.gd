extends "res://scripts/screen.gd"

var title1: Label
var title2: Label
var t := 0.0

func build() -> void:
	var sc := ScrollContainer.new()
	sc.set_anchors_preset(Control.PRESET_FULL_RECT)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(sc)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 10)
	sc.add_child(v)
	v.add_child(Control.new())
	title1 = UI.lbl("HOTLINE MIAMI", 64, UI.PINK)
	title2 = UI.lbl("R E D U X", 46, UI.CYAN)
	for l in [title1, title2]:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.add_theme_constant_override("outline_size", 10)
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
		v.add_child(l)
	var items := [
		[Settings.L("Новая игра", "New game"), func(): Game.start_level(Game.first_level())],
		[Settings.L("Продолжить", "Continue"), func(): Game.start_level(Game.continue_path())],
		[Settings.L("Выбор главы", "Chapters"), func(): go("res://scenes/level_select.tscn")],
		[Settings.L("Выбор уровней", "Levels"), func(): go("res://scenes/level_select.tscn")],
		[Settings.L("Маски", "Masks"), func(): go("res://scenes/masks.tscn")],
		[Settings.L("Оружие", "Weapons"), func(): go("res://scenes/weapons.tscn")],
		[Settings.L("Статистика", "Statistics"), func(): go("res://scenes/stats.tscn")],
		[Settings.L("Настройки", "Settings"), func(): go("res://scenes/settings.tscn")],
		[Settings.L("Авторы", "Credits"), func(): go("res://scenes/credits.tscn")],
		[Settings.L("Выход", "Quit"), func(): get_tree().quit()],
	]
	var cols := [UI.PINK, UI.CYAN, UI.YEL]
	var i := 0
	for it in items:
		var b := UI.btn(it[0], it[1], cols[i % 3], 520.0)
		b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		v.add_child(b)
		i += 1

func _process(dt: float) -> void:
	t += dt
	if title1:
		title1.modulate = Color.from_hsv(fmod(0.9 + sin(t * 0.7) * 0.05, 1.0), 0.8, 1.0)
		title1.position.x += randf_range(-1, 1) * (1.0 if fmod(t, 3.0) < 0.12 else 0.0)
