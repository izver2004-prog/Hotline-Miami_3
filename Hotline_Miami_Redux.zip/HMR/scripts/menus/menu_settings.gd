extends "res://scripts/screen.gd"

var body: VBoxContainer

func build() -> void:
	body = page(Settings.L("НАСТРОЙКИ", "SETTINGS"))
	_section(Settings.L("Графика", "Graphics"))
	_slider("pixel_scale", "Масштаб пикселей", "Pixel scale", 0.8, 2.5, 0.1)
	_option("fps_limit", "Ограничение FPS", "FPS limit", ["30", "60", "90", "120", "Без лимита"], [30, 60, 90, 120, 0])
	_toggle("vsync", "VSync", "VSync")
	_option("fx_quality", "Качество эффектов", "Effects quality", ["Выкл", "Низкое", "Высокое"], [0, 1, 2])
	_slider("vhs", "Интенсивность VHS", "VHS intensity", 0.0, 1.5, 0.05)
	_slider("brightness", "Яркость", "Brightness", 0.6, 1.6, 0.05)
	_slider("contrast", "Контрастность", "Contrast", 0.6, 1.8, 0.05)
	_option("color_filter", "Цветовой фильтр", "Color filter", ["Нет", "Маджента", "Циан", "Янтарь", "Ч/Б"], [0, 1, 2, 3, 4])
	_slider("fx_intensity", "Интенсивность эффектов", "Effects intensity", 0.0, 1.5, 0.05)
	_section(Settings.L("Звук", "Audio"))
	_slider("master", "Общая громкость", "Master", 0.0, 1.0, 0.05)
	_slider("music", "Музыка", "Music", 0.0, 1.0, 0.05)
	_slider("sfx", "Звуковые эффекты", "SFX", 0.0, 1.0, 0.05)
	_slider("ui_vol", "Громкость интерфейса", "UI volume", 0.0, 1.0, 0.05)
	_section(Settings.L("Управление", "Controls"))
	body.add_child(UI.btn(Settings.L("Редактор кнопок", "Button editor"), func(): go("res://scenes/controls_editor.tscn"), UI.CYAN, 400.0))
	_option("touch_mode", "Сенсорные кнопки", "Touch controls", ["Авто", "Всегда", "Никогда"], [0, 1, 2])
	_option("stick_mode", "Джойстик", "Joystick", ["Фиксированный", "Плавающий"], [0, 1])
	_slider("stick_sens", "Чувствительность", "Sensitivity", 0.5, 2.0, 0.05)
	_slider("stick_zone", "Зона плавающего стика", "Floating stick zone", 0.2, 0.7, 0.05)
	_section(Settings.L("Игровой процесс", "Gameplay"))
	_toggle("aim_assist", "Автоприцеливание", "Aim assist")
	_slider("assist_angle", "Помощь при прицеливании (градусы)", "Assist angle (deg)", 5.0, 40.0, 1.0)
	_toggle("vibration", "Вибрация", "Vibration")
	_toggle("hints", "Подсказки", "Hints")
	_slider("anim_speed", "Скорость анимаций", "Animation speed", 0.5, 2.0, 0.1)
	_section(Settings.L("Интерфейс", "Interface"))
	_option("language", "Язык", "Language", ["Русский", "English"], ["ru", "en"], true)
	_slider("ui_scale", "Масштаб интерфейса", "UI scale", 0.7, 1.5, 0.05, true)
	_slider("text_size", "Размер текста", "Text size", 0.8, 1.5, 0.05, true)
	_toggle("show_fps", "Показывать FPS", "Show FPS")

func _section(t: String) -> void:
	body.add_child(UI.lbl(t, 34, UI.CYAN))

func _row(label: String) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	var l := UI.lbl(label, 22)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.custom_minimum_size.x = 220
	h.add_child(l)
	body.add_child(h)
	return h

func _slider(key: String, ru: String, en: String, mn: float, mx: float, st: float, rebuild: bool = false) -> void:
	var h := _row(Settings.L(ru, en))
	var s := HSlider.new()
	s.min_value = mn
	s.max_value = mx
	s.step = st
	s.value = float(Settings.data[key])
	s.custom_minimum_size = Vector2(300, 48)
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var v := UI.lbl("%.2f" % s.value, 22, UI.YEL)
	v.custom_minimum_size.x = 70
	s.value_changed.connect(func(x: float):
		Settings.set_value(key, x)
		v.text = "%.2f" % x)
	if rebuild:
		s.drag_ended.connect(func(_c): get_tree().reload_current_scene())
	h.add_child(s)
	h.add_child(v)

func _toggle(key: String, ru: String, en: String) -> void:
	var h := _row(Settings.L(ru, en))
	var c := CheckButton.new()
	c.button_pressed = bool(Settings.data[key])
	c.focus_mode = Control.FOCUS_NONE
	c.toggled.connect(func(on: bool): Settings.set_value(key, on))
	h.add_child(c)

func _option(key: String, ru: String, en: String, labels: Array, values: Array, rebuild: bool = false) -> void:
	var h := _row(Settings.L(ru, en))
	var o := OptionButton.new()
	o.custom_minimum_size = Vector2(240, 52)
	o.add_theme_font_size_override("font_size", Settings.fs(22))
	var sel := 0
	for i in labels.size():
		o.add_item(labels[i], i)
		var cur = Settings.data[key]
		var same: bool = (float(values[i]) == float(cur)) if (typeof(values[i]) == TYPE_INT or typeof(values[i]) == TYPE_FLOAT) else (str(values[i]) == str(cur))
		if same:
			sel = i
	o.select(sel)
	o.item_selected.connect(func(i: int):
		Settings.set_value(key, values[i])
		if rebuild:
			get_tree().reload_current_scene())
	h.add_child(o)
