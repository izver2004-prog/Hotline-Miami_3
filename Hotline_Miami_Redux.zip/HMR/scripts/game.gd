extends Node
## Прогресс, сохранения (user://save.json), список уровней, ранги, разблокировки.

const SAVE_PATH := "user://save.json"

var save := {}
var chapters: Array = []
var current_level := ""
var meta_cache := {}

func _ready() -> void:
	_load()
	scan_levels()

func _default_save() -> Dictionary:
	return {
		"done": {}, "masks": ["fox"], "weapons": ["fists", "knife", "bat", "pistol"],
		"mask": "fox", "last_level": "",
		"stats": {"kills": 0, "deaths": 0, "levels": 0, "rank_s": 0, "max_combo": 0,
			"shots": 0, "melee_kills": 0, "throw_kills": 0, "playtime": 0.0},
	}

func _load() -> void:
	save = _default_save()
	if FileAccess.file_exists(SAVE_PATH):
		var j = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
		if j is Dictionary:
			for k in j:
				if k == "stats":
					for s in j[k]:
						save["stats"][s] = j[k][s]
				else:
					save[k] = j[k]

func write_save() -> void:
	var tmp := SAVE_PATH + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(save))
	f.close()
	var d := DirAccess.open("user://")
	if d:
		if FileAccess.file_exists(SAVE_PATH):
			d.remove("save.json")
		d.rename("save.json.tmp", "save.json")

func reset_progress() -> void:
	save = _default_save()
	write_save()

func stat(k: String) -> float:
	if k == "weapons_found":
		return float(save["weapons"].size())
	return float(save["stats"].get(k, 0))

func add_stat(k: String, v: float = 1.0) -> void:
	save["stats"][k] = float(save["stats"].get(k, 0)) + v

func scan_levels() -> void:
	chapters.clear()
	var d := DirAccess.open("res://levels")
	if d == null:
		return
	var dirs := Array(d.get_directories())
	dirs.sort()
	for dn in dirs:
		var sub := DirAccess.open("res://levels/" + str(dn))
		if sub == null:
			continue
		var files: Array = []
		for f in sub.get_files():
			var n: String = str(f).trim_suffix(".remap")
			if n.ends_with(".lvl"):
				files.append("res://levels/%s/%s" % [dn, n])
		files.sort()
		if files.size() > 0:
			chapters.append({"id": str(dn), "name": str(dn).to_upper(), "levels": files})

func parse_level(path: String) -> Dictionary:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return {}
	var meta := {"path": path}
	var rows: Array = []
	var in_map := false
	while not f.eof_reached():
		var line := f.get_line().trim_suffix("\r")
		if not in_map:
			if line.strip_edges() == "---":
				in_map = true
				continue
			var kv := line.split("=", true, 1)
			if kv.size() == 2:
				meta[kv[0].strip_edges()] = kv[1].strip_edges()
		else:
			rows.append(line)
	while rows.size() > 0 and str(rows[rows.size() - 1]).strip_edges() == "":
		rows.pop_back()
	meta["rows"] = rows
	return meta

func level_meta(path: String) -> Dictionary:
	if not meta_cache.has(path):
		meta_cache[path] = parse_level(path)
	return meta_cache[path]

func is_unlocked(ci: int, li: int) -> bool:
	var ch: Dictionary = chapters[ci]
	if ch["id"] == "test" or li == 0:
		return true
	return save["done"].has(ch["levels"][li - 1])

func first_level() -> String:
	if chapters.is_empty():
		return ""
	return chapters[0]["levels"][0]

func continue_path() -> String:
	var p: String = str(save.get("last_level", ""))
	if p != "" and FileAccess.file_exists(p):
		return p
	return first_level()

func next_level_path() -> String:
	var all: Array = []
	for c in chapters:
		all.append_array(c["levels"])
	var i := all.find(current_level)
	if i >= 0 and i + 1 < all.size():
		return all[i + 1]
	return ""

func start_level(path: String) -> void:
	current_level = path
	save["last_level"] = path
	write_save()
	Fx.change_scene("res://scenes/game.tscn")

func rank_for(ratio: float) -> String:
	if ratio >= 1.3: return "S"
	if ratio >= 1.0: return "A"
	if ratio >= 0.75: return "B"
	if ratio >= 0.5: return "C"
	return "D"

func finish_level(res: Dictionary) -> Dictionary:
	var meta := level_meta(current_level)
	var par := float(meta.get("par_score", float(res["total"]) * 1200.0 + 500.0))
	var rank := rank_for(float(res["score"]) / maxf(1.0, par))
	res["rank"] = rank
	var prev: Dictionary = save["done"].get(current_level, {})
	var order := "DCBAS"
	var was_s: bool = prev.get("rank", "D") == "S"
	if prev.is_empty() or int(res["score"]) > int(prev.get("best", 0)):
		prev["best"] = int(res["score"])
	prev["time"] = minf(float(prev.get("time", 9999.0)), float(res["time"]))
	if prev.get("rank", "") == "" or order.find(rank) > order.find(str(prev["rank"])):
		prev["rank"] = rank
	save["done"][current_level] = prev
	add_stat("levels")
	if rank == "S" and not was_s:
		add_stat("rank_s")
	res["unlocked"] = check_unlocks()
	write_save()
	return res

func cond_met(cond: String) -> bool:
	if cond == "start":
		return true
	var p := cond.split(":")
	return stat(p[0]) >= float(p[1])

func check_unlocks() -> Array:
	var out: Array = []
	for id in Data.masks_order:
		if not save["masks"].has(id) and cond_met(Data.mask(id)["unlock"]):
			save["masks"].append(id)
			out.append(id)
	return out

func found_weapon(id: String) -> void:
	if not save["weapons"].has(id):
		save["weapons"].append(id)
