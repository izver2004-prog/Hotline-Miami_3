extends Node
## Настройки и раскладка сенсорных кнопок. Сохраняются в user://settings.json

signal changed

const PATH := "user://settings.json"
const BTN_NAMES := ["stick", "attack", "melee", "interact", "pickup", "swap", "aim", "run"]

var data := {}
var controls := {}

func _defaults() -> Dictionary:
	return {
		"master": 1.0, "music": 0.8, "sfx": 1.0, "ui_vol": 0.8,
		"fps_limit": 60, "vsync": true, "pixel_scale": 1.0,
		"fx_quality": 2, "vhs": 0.6, "brightness": 1.0, "contrast": 1.1,
		"color_filter": 0, "fx_intensity": 1.0,
		"aim_assist": true, "assist_angle": 18.0, "vibration": true,
		"hints": true, "anim_speed": 1.0,
		"language": "ru", "ui_scale": 1.0, "show_fps": false, "text_size": 1.0,
		"stick_mode": 0, "stick_sens": 1.0, "stick_zone": 0.45, "touch_mode": 0,
	}

func _b(x: float, y: float, s: float) -> Dictionary:
	return {"x": x, "y": y, "size": s, "alpha": 0.6}

func default_controls() -> Dictionary:
	return {
		"stick": _b(0.13, 0.72, 190.0), "attack": _b(0.89, 0.70, 140.0),
		"melee": _b(0.77, 0.84, 104.0), "interact": _b(0.66, 0.88, 88.0),
		"pickup": _b(0.91, 0.40, 92.0), "swap": _b(0.80, 0.34, 88.0),
		"aim": _b(0.75, 0.60, 100.0), "run": _b(0.27, 0.86, 100.0),
	}

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	data = _defaults()
	controls = default_controls()
	if FileAccess.file_exists(PATH):
		var j = JSON.parse_string(FileAccess.get_file_as_string(PATH))
		if j is Dictionary:
			var d = j.get("data", {})
			for k in d:
				if data.has(k):
					data[k] = d[k]
			var c = j.get("controls", {})
			for k in c:
				if controls.has(k):
					for kk in c[k]:
						controls[k][kk] = c[k][kk]
	apply()

func save_settings() -> void:
	var tmp := PATH + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify({"data": data, "controls": controls}))
	f.close()
	var d := DirAccess.open("user://")
	if d:
		if FileAccess.file_exists(PATH):
			d.remove("settings.json")
		d.rename("settings.json.tmp", "settings.json")

func set_value(k: String, v) -> void:
	data[k] = v
	apply()
	changed.emit()

func reset_controls() -> void:
	controls = default_controls()
	data["stick_mode"] = 0
	data["stick_sens"] = 1.0
	data["stick_zone"] = 0.45
	changed.emit()

func fs(n: int) -> int:
	return int(float(n) * float(data["text_size"]))

func L(ru: String, en: String) -> String:
	return ru if data["language"] == "ru" else en

func apply_scale() -> void:
	get_tree().root.content_scale_factor = float(data["ui_scale"])

func apply() -> void:
	Engine.max_fps = int(data["fps_limit"])
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED if data["vsync"] else DisplayServer.VSYNC_DISABLED)
	var map := {"Master": "master", "Music": "music", "SFX": "sfx", "UI": "ui_vol"}
	for b in map:
		var idx := AudioServer.get_bus_index(b)
		if idx >= 0:
			AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(0.0001, float(data[map[b]]))))
