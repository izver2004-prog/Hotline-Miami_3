extends Node
## Хелперы для неонового UI.

const PINK := Color(1.0, 0.18, 0.58)
const CYAN := Color(0.0, 0.94, 1.0)
const YEL := Color(1.0, 0.88, 0.29)
const DARK := Color(0.04, 0.02, 0.08, 0.88)

func sb(bg: Color, border: Color, bw: int = 3) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.content_margin_left = 16
	s.content_margin_right = 16
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	return s

func btn(text: String, cb: Callable, col: Color = PINK, minw: float = 0.0) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", Settings.fs(26))
	b.add_theme_color_override("font_color", col)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color.BLACK)
	b.add_theme_stylebox_override("normal", sb(DARK, col))
	b.add_theme_stylebox_override("hover", sb(col.darkened(0.65), col.lightened(0.3)))
	b.add_theme_stylebox_override("pressed", sb(col, Color.WHITE))
	b.add_theme_stylebox_override("disabled", sb(Color(0.1, 0.1, 0.12, 0.7), Color(0.3, 0.3, 0.35)))
	b.custom_minimum_size = Vector2(minw, 60)
	b.pressed.connect(func():
		Audio.play("ui_click")
		cb.call())
	return b

func lbl(text: String, size: int = 24, col: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", Settings.fs(size))
	l.add_theme_color_override("font_color", col)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

func panel(col: Color = CYAN) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", sb(DARK, col, 3))
	return p
