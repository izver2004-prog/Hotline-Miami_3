extends StaticBody2D
## Дверь: открывается касанием/кнопкой «взаимодействие», оглушает врагов рядом при открытии (маска Носорога).

var level
var is_open := false
var vertical := false   # true: полоса вертикальная (проход слева-направо)
var theme_id := "club"
var angle := 0.0

func setup(lv, wall_left_right: bool, th: String) -> void:
	level = lv
	theme_id = th
	vertical = not wall_left_right
	collision_layer = 1
	collision_mask = 0
	add_to_group("doors")
	var cs := CollisionShape2D.new()
	var rs := RectangleShape2D.new()
	rs.size = Vector2(8, 32) if vertical else Vector2(32, 8)
	cs.shape = rs
	cs.name = "Shape"
	add_child(cs)

func open(by_player: bool = false) -> void:
	if is_open:
		return
	is_open = true
	Audio.play("door")
	get_node("Shape").set_deferred("disabled", true)
	var tw := create_tween()
	tw.tween_property(self, "angle", -PI / 2.0 if not vertical else PI / 2.0, 0.18)
	if by_player and level.player.mods.has("doorstun"):
		for e in level.enemies:
			if is_instance_valid(e) and e.state != "dead" and e.global_position.distance_to(global_position) < 48.0:
				e.stun = 1.8
	level.make_noise(global_position, 120.0)

func toggle() -> void:
	if is_open:
		close()
	else:
		open(true)

func close() -> void:
	if not is_open:
		return
	for b in [level.player] + level.enemies:
		if is_instance_valid(b) and b.global_position.distance_to(global_position) < 22.0:
			return
	is_open = false
	Audio.play("door", 0.7)
	get_node("Shape").set_deferred("disabled", false)
	angle = 0.0

func _process(_dt: float) -> void:
	queue_redraw()

func _draw() -> void:
	var c := Color(Data.theme(theme_id)["neon"])
	var r := Rect2(-16, -4, 32, 8) if not vertical else Rect2(-4, -16, 8, 32)
	if is_open:
		# створка, повёрнутая на петле
		var hinge := Vector2(-16, 0) if not vertical else Vector2(0, -16)
		draw_set_transform(hinge, angle, Vector2.ONE)
		var rr := Rect2(0, -3, 32, 6) if not vertical else Rect2(-3, 0, 6, 32)
		draw_rect(rr, Color("5a3a22"))
		draw_rect(rr, c.darkened(0.2), false, 1.0)
	else:
		draw_rect(r, Color("5a3a22"))
		draw_rect(r, c, false, 2.0)
