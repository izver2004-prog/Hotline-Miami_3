extends Node
## Процедурная пиксель-арт графика (16x16 / 24x24 текстуры, рисуются в коде, масштабируются x2 без сглаживания).

const OUT := Color(0.043, 0.024, 0.078)
var cache := {}

func _img(w: int, h: int) -> Image:
	var i := Image.create(w, h, false, Image.FORMAT_RGBA8)
	i.fill(Color(0, 0, 0, 0))
	return i

func _px(i: Image, x: int, y: int, c: Color) -> void:
	if x >= 0 and y >= 0 and x < i.get_width() and y < i.get_height():
		i.set_pixel(x, y, c)

func _rect(i: Image, x: int, y: int, w: int, h: int, c: Color) -> void:
	for yy in range(y, y + h):
		for xx in range(x, x + w):
			_px(i, xx, yy, c)

func _ell(i: Image, cx: float, cy: float, rx: float, ry: float, c: Color) -> void:
	for yy in range(int(cy - ry) - 1, int(cy + ry) + 2):
		for xx in range(int(cx - rx) - 1, int(cx + rx) + 2):
			var dx: float = (float(xx) + 0.5 - cx) / rx
			var dy: float = (float(yy) + 0.5 - cy) / ry
			if dx * dx + dy * dy <= 1.0:
				_px(i, xx, yy, c)

func _tri(i: Image, x: int, y: int, w: int, h: int, c: Color) -> void:
	for r in h:
		var ww: int = int(float(w) * (1.0 - float(r) / float(h)))
		_rect(i, x + (w - ww) / 2, y + r, maxi(1, ww), 1, c)

func _outline(i: Image) -> Image:
	var o: Image = i.duplicate()
	for y in i.get_height():
		for x in i.get_width():
			if i.get_pixel(x, y).a < 0.5:
				for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
					var nx: int = x + d.x
					var ny: int = y + d.y
					if nx >= 0 and ny >= 0 and nx < i.get_width() and ny < i.get_height() and i.get_pixel(nx, ny).a > 0.5:
						o.set_pixel(x, y, OUT)
						break
	return o

func _tex(i: Image) -> ImageTexture:
	return ImageTexture.create_from_image(i)

# ---------- персонажи ----------
func person_tex(key: String, shirt: Color, head: Color, frame: int, accent: Color, ears: String) -> ImageTexture:
	if cache.has(key):
		return cache[key]
	var i := _img(16, 16)
	var skin := Color("e8b98a")
	var o: int = 1 if frame == 1 else -1
	_rect(i, 4 + o, 3, 3, 3, Color("1a1a2e"))
	_rect(i, 4 - o, 10, 3, 3, Color("1a1a2e"))
	_ell(i, 8, 8, 3.2, 5.6, shirt)
	_rect(i, 9, 3, 4 + frame, 2, skin)
	_rect(i, 9, 11, 5 - frame, 2, skin)
	match ears:
		"point":
			_rect(i, 6, 4, 2, 2, head)
			_rect(i, 6, 10, 2, 2, head)
		"round":
			_ell(i, 7, 4.5, 1.6, 1.6, head)
			_ell(i, 7, 11.5, 1.6, 1.6, head)
		"horn":
			_rect(i, 8, 3, 3, 1, Color.WHITE)
			_rect(i, 8, 12, 3, 1, Color.WHITE)
		"beak":
			_rect(i, 11, 7, 3, 2, accent)
	_ell(i, 8, 8, 3.4, 3.4, head)
	_px(i, 10, 7, accent)
	_px(i, 10, 9, accent)
	var t := _tex(_outline(i))
	cache[key] = t
	return t

func player_tex(mask_id: String, frame: int) -> ImageTexture:
	var m: Dictionary = Data.mask(mask_id)
	return person_tex("p_%s_%d" % [mask_id, frame], Color("3b6fd8"), Color(m["c"]), frame, Color(m["a"]), m["ears"])

func enemy_tex(kind: String, frame: int) -> ImageTexture:
	var k: Dictionary = Data.ENEMIES[kind]
	return person_tex("e_%s_%d" % [kind, frame], Color(k["shirt"]), Color("e8b98a"), frame, Color("1a1a2e"), "")

func weapon_tex(id: String) -> ImageTexture:
	var key := "w_" + id
	if cache.has(key):
		return cache[key]
	var w: Dictionary = Data.weapon(id)
	var c := Color(w["col"])
	var L: int = int(w["len"])
	var th: int = int(w["th"])
	var i := _img(16, 16)
	var cy := 8 - th / 2
	match w["type"]:
		"gun":
			_rect(i, 3, cy, L, th, c.darkened(0.15))
			_rect(i, 3, cy + th, 3, 3, c.darkened(0.45))
			_rect(i, 3 + L / 2, cy, L / 2, 1, c.lightened(0.3))
		"melee":
			_rect(i, 1, 7, 4, 2, Color("5a3a22"))
			_rect(i, 5, cy, L, th, c)
			if w["fx"].contains("wide") or id == "axe" or id == "hammer":
				_rect(i, 4 + L - 2, 8 - 3, 3, 6, c.darkened(0.2))
			_rect(i, 5 + L / 2, cy, L / 2, 1, c.lightened(0.35))
		_:
			if id == "grenade" or id == "bottle" or id == "brick":
				_ell(i, 8, 8, 3.5, 3.0, c)
				_px(i, 9, 7, c.lightened(0.5))
			else:
				_rect(i, 4, 7, 7, 2, c)
				_rect(i, 7, 5, 2, 6, c)
	var t := _tex(_outline(i))
	cache[key] = t
	return t

func mask_icon(id: String) -> ImageTexture:
	var key := "m_" + id
	if cache.has(key):
		return cache[key]
	var m: Dictionary = Data.mask(id)
	var c := Color(m["c"])
	var a := Color(m["a"])
	var i := _img(24, 24)
	match m["ears"]:
		"point":
			_tri(i, 3, 1, 7, 9, c)
			_tri(i, 14, 1, 7, 9, c)
		"round":
			_ell(i, 5, 5, 3.5, 3.5, c)
			_ell(i, 19, 5, 3.5, 3.5, c)
		"horn":
			_tri(i, 2, 0, 5, 10, Color.WHITE)
			_tri(i, 17, 0, 5, 10, Color.WHITE)
		"beak":
			_tri(i, 9, 15, 6, 8, a)
	_ell(i, 12, 13, 8.5, 9.0, c)
	match m["pat"]:
		"stripes":
			for x in [7, 12, 17]:
				_rect(i, x, 6, 1, 4, c.darkened(0.5))
		"dots":
			for p in [Vector2i(6, 17), Vector2i(17, 17), Vector2i(9, 20), Vector2i(14, 20)]:
				_px(i, p.x, p.y, c.darkened(0.45))
		"cross":
			_rect(i, 11, 5, 2, 17, c.darkened(0.45))
			_rect(i, 5, 15, 14, 2, c.darkened(0.45))
	_rect(i, 6, 11, 4, 2, a)
	_rect(i, 14, 11, 4, 2, a)
	_px(i, 8, 11, Color.WHITE)
	_px(i, 16, 11, Color.WHITE)
	if m["ears"] != "beak":
		_rect(i, 10, 17, 4, 1, c.darkened(0.55))
	var t := _tex(_outline(i))
	cache[key] = t
	return t

# ---------- окружение ----------
func floor_tex(theme_id: String, v: int) -> ImageTexture:
	var key := "f_%s_%d" % [theme_id, v]
	if cache.has(key):
		return cache[key]
	var t: Dictionary = Data.theme(theme_id)
	var c1 := Color(t["f1"])
	var c2 := Color(t["f2"])
	var neon := Color(t["neon"])
	if v == 1:
		var tmp := c1
		c1 = c2.lightened(0.12)
		c2 = tmp.darkened(0.1)
	elif v == 2:
		c1 = c1.lerp(neon, 0.14)
		c2 = c2.lerp(neon, 0.14)
	var i := _img(16, 16)
	var r := RandomNumberGenerator.new()
	r.seed = hash(key)
	for y in 16:
		for x in 16:
			var col := c1
			match t["pat"]:
				"checker":
					col = c1 if (((x >> 3) + (y >> 3)) % 2) == 0 else c2
				"wood":
					col = c1 if ((y >> 2) % 2) == 0 else c2
					if y % 4 == 0:
						col = col.darkened(0.3)
					if (x + (y >> 2) * 5) % 16 == 0:
						col = col.darkened(0.25)
				"carpet":
					col = c2 if r.randf() < 0.25 else c1
				"concrete":
					col = c2 if r.randf() < 0.14 else c1
					if x == y and y > 4 and y < 10:
						col = c2.darkened(0.3)
				"tile":
					col = c1 if (((x >> 3) + (y >> 3)) % 2) == 0 else c2
					if x % 8 == 0 or y % 8 == 0:
						col = c2.darkened(0.35)
			i.set_pixel(x, y, col)
	var tex := _tex(i)
	cache[key] = tex
	return tex

func wall_tex(theme_id: String) -> ImageTexture:
	var key := "wt_" + theme_id
	if cache.has(key):
		return cache[key]
	var t: Dictionary = Data.theme(theme_id)
	var base := Color(t["wall"])
	var i := _img(16, 16)
	for y in 16:
		for x in 16:
			var col := base
			if y % 4 == 0:
				col = base.darkened(0.35)
			elif (x + ((y >> 2) % 2) * 4) % 8 == 0:
				col = base.darkened(0.35)
			elif (x + y) % 11 == 0:
				col = base.lightened(0.08)
			i.set_pixel(x, y, col)
	for x in 16:
		i.set_pixel(x, 0, Color(t["neon"]))
		i.set_pixel(x, 1, Color(t["neon"]).darkened(0.4))
	var tex := _tex(i)
	cache[key] = tex
	return tex

func wall_front_tex(theme_id: String) -> ImageTexture:
	var key := "wf_" + theme_id
	if cache.has(key):
		return cache[key]
	var t: Dictionary = Data.theme(theme_id)
	var base := Color(t["wall"]).darkened(0.55)
	var i := _img(16, 8)
	for y in 8:
		for x in 16:
			i.set_pixel(x, y, base.darkened(0.08 * y) if (x + y) % 5 != 0 else base.darkened(0.3))
	for x in 16:
		i.set_pixel(x, 0, Color(t["neon"]).darkened(0.2))
	var tex := _tex(i)
	cache[key] = tex
	return tex

func furn_tex(kind: String, theme_id: String) -> ImageTexture:
	var key := "fu_%s_%s" % [kind, theme_id]
	if cache.has(key):
		return cache[key]
	var i := _img(16, 16)
	if kind == "T":
		_rect(i, 1, 2, 14, 12, Color("7a5230"))
		_rect(i, 2, 3, 12, 10, Color("9a6b3f"))
		_rect(i, 3, 4, 4, 2, Color("c79a64"))
		_px(i, 11, 9, Color(Data.theme(theme_id)["neon"]))
	else:
		_rect(i, 1, 1, 14, 14, Color("8a5a2b"))
		_rect(i, 2, 2, 12, 12, Color("a8743a"))
		for k in 12:
			_px(i, 2 + k, 2 + k, Color("5a3a1a"))
			_px(i, 13 - k, 2 + k, Color("5a3a1a"))
	var tex := _tex(_outline(i))
	cache[key] = tex
	return tex

func glow_tex() -> ImageTexture:
	if cache.has("glow"):
		return cache["glow"]
	var i := _img(64, 64)
	for y in 64:
		for x in 64:
			var d: float = Vector2(x - 31.5, y - 31.5).length() / 32.0
			i.set_pixel(x, y, Color(1, 1, 1, clampf(1.0 - d, 0.0, 1.0) * clampf(1.0 - d, 0.0, 1.0)))
	var tex := _tex(i)
	cache["glow"] = tex
	return tex

func blood_tex(v: int) -> ImageTexture:
	var key := "b_%d" % v
	if cache.has(key):
		return cache[key]
	var i := _img(24, 24)
	var r := RandomNumberGenerator.new()
	r.seed = v * 77 + 5
	_ell(i, 12, 12, 5 + v, 4 + v, Color(0.55, 0.02, 0.1, 0.9))
	for k in 9:
		_ell(i, 12 + r.randf_range(-9, 9), 12 + r.randf_range(-9, 9), r.randf_range(1, 3), r.randf_range(1, 3), Color(0.7, 0.03, 0.12, 0.9))
	var tex := _tex(i)
	cache[key] = tex
	return tex
