extends Node
## Каталог: 25 видов оружия, 20 масок, типы врагов, темы локаций.

const WF := ["id", "ru", "en", "type", "dmg", "rate", "mag", "reserve", "spread", "pellets",
	"speed", "rng", "reload", "noise", "col", "len", "th", "fx", "snd", "desc"]
const WROWS := [
	["fists", "Кулаки", "Fists", "melee", 0, 0.35, 0, 0, 0, 1, 0, 28, 0, 60, "d9b38c", 3, 2, "stun", "swing", "Оглушает. Добить оглушённого — удар."],
	["knife", "Нож", "Knife", "melee", 1, 0.26, 0, 0, 0, 1, 0, 30, 0, 50, "cfd8dc", 6, 1, "", "swing", "Быстрый и тихий."],
	["bat", "Бита", "Bat", "melee", 2, 0.5, 0, 0, 0, 1, 0, 40, 0, 70, "b5803f", 9, 3, "", "swing", "Убивает тяжёлых с одного удара."],
	["crowbar", "Монтировка", "Crowbar", "melee", 2, 0.45, 0, 0, 0, 1, 0, 38, 0, 70, "8e9aa6", 9, 2, "", "swing", "Надёжная классика."],
	["katana", "Катана", "Katana", "melee", 2, 0.3, 0, 0, 0, 1, 0, 52, 0, 50, "e8f4ff", 12, 1, "wide", "swing", "Длинная, широкий замах."],
	["machete", "Мачете", "Machete", "melee", 2, 0.32, 0, 0, 0, 1, 0, 40, 0, 50, "b0bec5", 8, 2, "", "swing", "Быстрое и тяжёлое."],
	["axe", "Топор", "Axe", "melee", 3, 0.7, 0, 0, 0, 1, 0, 40, 0, 80, "a1887f", 9, 2, "wide", "swing", "Медленный, но широкий."],
	["pipe", "Труба", "Pipe", "melee", 2, 0.42, 0, 0, 0, 1, 0, 40, 0, 70, "78909c", 10, 2, "", "swing", "Тяжёлая труба."],
	["hammer", "Кувалда", "Sledgehammer", "melee", 3, 0.8, 0, 0, 0, 1, 0, 40, 0, 90, "90a4ae", 9, 3, "wide", "swing", "Очень медленная и очень смертельная."],
	["pistol", "Пистолет", "Pistol", "gun", 1, 0.28, 12, 24, 3, 1, 700, 520, 1.0, 380, "9aa5b1", 7, 2, "", "shot", "Точный и надёжный."],
	["revolver", "Револьвер", "Revolver", "gun", 1, 0.55, 6, 18, 1.5, 1, 800, 600, 1.5, 420, "b08d57", 8, 2, "pierce", "shot", "Пробивает одного врага."],
	["deagle", "Дезерт", "Desert Eagle", "gun", 2, 0.45, 7, 14, 2, 1, 850, 650, 1.4, 450, "c9ced6", 9, 3, "pierce", "shot", "Мощный и громкий."],
	["smg", "ПП", "SMG", "gun", 1, 0.09, 30, 60, 7, 1, 650, 450, 1.4, 400, "7d8791", 9, 2, "", "smg", "Высокий темп огня."],
	["uzi", "Узи", "Uzi", "gun", 1, 0.06, 25, 50, 9, 1, 620, 380, 1.3, 400, "8a929b", 7, 2, "", "smg", "Максимальный темп, плохая кучность."],
	["shotgun", "Дробовик", "Shotgun", "gun", 1, 0.75, 6, 12, 14, 6, 620, 300, 1.6, 520, "6d4c41", 12, 2, "", "shotgun", "Шесть дробин, ближняя дистанция."],
	["sawedoff", "Обрез", "Sawed-off", "gun", 1, 0.6, 2, 8, 20, 8, 600, 220, 1.2, 520, "5d4037", 8, 2, "", "shotgun", "Два выстрела и пара метров."],
	["rifle", "Автомат", "Assault Rifle", "gun", 1, 0.11, 30, 60, 4, 1, 800, 700, 1.6, 450, "5f6b57", 12, 2, "", "smg", "Дальний и точный."],
	["sniper", "Снайперка", "Sniper", "gun", 2, 1.1, 5, 10, 0, 1, 1500, 1400, 2.0, 500, "4e5d4a", 14, 2, "pierce", "shot", "Пробивает насквозь."],
	["crossbow", "Арбалет", "Crossbow", "gun", 2, 0.9, 1, 10, 1, 1, 600, 600, 1.0, 0, "8d6e63", 9, 2, "pierce,silent", "swing", "Бесшумный."],
	["nailgun", "Гвоздомёт", "Nailgun", "gun", 1, 0.12, 40, 80, 5, 1, 600, 380, 1.5, 200, "ff7a1a", 8, 2, "", "smg", "Тихий и скорострельный."],
	["throwing_knife", "Метательный нож", "Throwing Knife", "throw", 1, 0.3, 5, 0, 0, 1, 650, 380, 0, 0, "cfd8dc", 5, 1, "silent", "swing", "Бесшумный бросок."],
	["shuriken", "Сюрикен", "Shuriken", "throw", 1, 0.25, 8, 0, 0, 1, 700, 420, 0, 0, "b0bec5", 4, 3, "silent", "swing", "Много штук."],
	["bottle", "Бутылка", "Bottle", "throw", 1, 0.5, 1, 0, 0, 1, 520, 320, 0, 200, "4caf50", 4, 2, "glass", "glass", "Разбивается о цель."],
	["brick", "Кирпич", "Brick", "throw", 1, 0.5, 1, 0, 0, 1, 480, 300, 0, 100, "a1523c", 4, 3, "", "hit", "Тяжёлый бросок."],
	["grenade", "Граната", "Grenade", "throw", 3, 0.7, 1, 0, 0, 1, 380, 320, 0, 400, "556b2f", 4, 3, "explode", "explode", "Взрывается при касании."],
]

# id, ru, en, описание, способность, mods, цвет, акцент, уши, узор, условие разблокировки
const MROWS := [
	["fox", "Лиса", "Fox", "Хитрая и быстрая.", "+15% скорость", {"speed": 1.15}, "ff7a1a", "fff3d6", "point", "stripes", "start"],
	["wolf", "Волк", "Wolf", "Серый охотник.", "+20% дальность ближнего боя", {"reach": 1.2}, "8e9aa6", "ffe14a", "point", "none", "kills:25"],
	["raven", "Ворон", "Raven", "Тёмный вестник.", "Метательное летит на 50% быстрее", {"throw": 1.5}, "2b2b3a", "b84dff", "beak", "none", "levels:2"],
	["panther", "Пантера", "Panther", "Тень в клубе.", "Враги замечают на 20% хуже", {"stealth": 0.8}, "1a1a24", "00f0ff", "round", "none", "kills:60"],
	["bull", "Бык", "Bull", "Не сдаётся.", "Переживает одно попадание", {"armor": 1}, "c0392b", "ffffff", "horn", "none", "deaths:10"],
	["owl", "Сова", "Owl", "Видит ночью.", "+1.5 с окна комбо", {"combo": 1.5}, "a1887f", "ffe14a", "round", "dots", "max_combo:5"],
	["snake", "Змея", "Snake", "Холодный расчёт.", "Очки x1.25", {"score": 1.25}, "2ecc71", "ffe14a", "none", "stripes", "melee_kills:20"],
	["bear", "Медведь", "Bear", "Грубая сила.", "+1 урон в ближнем бою, -8% скорость", {"melee_bonus": 1, "speed": 0.92}, "6d4c41", "d7ccc8", "round", "none", "kills:120"],
	["tiger", "Тигр", "Tiger", "Полосатый хищник.", "Атакует на 20% быстрее", {"rate": 0.8}, "ff9f1a", "1a1a24", "round", "stripes", "levels:5"],
	["rabbit", "Заяц", "Rabbit", "Не догонишь.", "+30% скорость бега", {"run": 1.3}, "ecf0f1", "ff2d95", "point", "none", "levels:3"],
	["shark", "Акула", "Shark", "Запасливая.", "+50% патронов", {"ammo": 1.5}, "5d7a99", "ffffff", "none", "dots", "weapons_found:10"],
	["rhino", "Носорог", "Rhino", "Выбивает двери.", "Дверь оглушает врагов рядом", {"doorstun": 1}, "7f8c8d", "ff2d95", "horn", "none", "levels:8"],
	["cobra", "Кобра", "Cobra", "Смертельный укус.", "Пули пробивают +1 врага", {"pierce": 1}, "27ae60", "ff2d95", "none", "cross", "rank_s:1"],
	["eagle", "Орёл", "Eagle", "Зоркий глаз.", "+30% скорость пуль, -40% разброс", {"bspeed": 1.3, "accuracy": 0.6}, "f5f5f5", "ffe14a", "beak", "none", "shots:500"],
	["gorilla", "Горилла", "Gorilla", "Ловкие руки.", "Подбор x2 радиус, перезарядка -30%", {"pickup": 2.0, "reload": 0.7}, "3e3e46", "00f0ff", "round", "none", "kills:250"],
	["dragon", "Дракон", "Dragon", "Огонь и золото.", "Очки x1.5, -5% скорость", {"score": 1.5, "speed": 0.95}, "e74c3c", "ffe14a", "horn", "cross", "rank_s:3"],
	["skull", "Череп", "Skull", "Играй с риском.", "Очки x2, без защиты", {"score": 2.0}, "ecf0f1", "ff2d95", "none", "cross", "deaths:30"],
	["monkey", "Обезьяна", "Monkey", "Мастер бросков.", "Метательное +30%, подбор +50%", {"throw": 1.3, "pickup": 1.5}, "a0522d", "ffe14a", "round", "none", "throw_kills:10"],
	["horse", "Конь", "Horse", "Бодрый галоп.", "+10% скорость и бега", {"speed": 1.1, "run": 1.1}, "d2b48c", "ff2d95", "point", "stripes", "levels:10"],
	["phantom", "Призрак", "Phantom", "Ты — слух.", "Враги видят -40%, выстрелы тихие", {"stealth": 0.6, "silent": 1}, "dfe6f0", "b84dff", "none", "dots", "rank_s:5"],
]

const COND_RU := {"kills": "Убийств", "levels": "Пройдено уровней", "deaths": "Смертей", "max_combo": "Макс. комбо",
	"melee_kills": "Убийств в ближнем бою", "weapons_found": "Найдено видов оружия", "rank_s": "Рангов S",
	"shots": "Выстрелов", "throw_kills": "Убийств броском"}

const ENEMIES := {
	"thug": {"w": "bat", "hp": 1, "spd": 110.0, "sight": 240.0, "fov": 110.0, "rng": 0.0, "beh": "idle", "shirt": "c0392b", "score": 100},
	"runner": {"w": "knife", "hp": 1, "spd": 150.0, "sight": 260.0, "fov": 120.0, "rng": 0.0, "beh": "patrol", "shirt": "e67e22", "score": 120},
	"gunman": {"w": "pistol", "hp": 1, "spd": 95.0, "sight": 330.0, "fov": 120.0, "rng": 260.0, "beh": "idle", "shirt": "2980b9", "score": 120},
	"patrol": {"w": "pistol", "hp": 1, "spd": 90.0, "sight": 320.0, "fov": 110.0, "rng": 250.0, "beh": "patrol", "shirt": "16a085", "score": 130},
	"shotgunner": {"w": "shotgun", "hp": 1, "spd": 90.0, "sight": 300.0, "fov": 110.0, "rng": 200.0, "beh": "idle", "shirt": "8e44ad", "score": 150},
	"rifleman": {"w": "smg", "hp": 1, "spd": 95.0, "sight": 340.0, "fov": 110.0, "rng": 280.0, "beh": "patrol", "shirt": "d35400", "score": 160},
	"heavy": {"w": "bat", "hp": 2, "spd": 85.0, "sight": 260.0, "fov": 100.0, "rng": 0.0, "beh": "idle", "shirt": "2c3e50", "score": 250},
}

const THEMES := {
	"club": {"pat": "checker", "f1": "2a1745", "f2": "1e1038", "wall": "3a1a66", "neon": "ff2d95"},
	"office": {"pat": "carpet", "f1": "2e3b4e", "f2": "263243", "wall": "54657d", "neon": "00f0ff"},
	"apartment": {"pat": "wood", "f1": "6b4a2f", "f2": "5a3d27", "wall": "7a3b4f", "neon": "ffe14a"},
	"warehouse": {"pat": "concrete", "f1": "4a4a52", "f2": "3f3f47", "wall": "6a5a48", "neon": "ff7a1a"},
	"hotel": {"pat": "tile", "f1": "7a2f4a", "f2": "5f243a", "wall": "b08a4a", "neon": "b84dff"},
}

var weapons := {}
var weapon_order: Array = []
var masks := {}
var masks_order: Array = []

func _ready() -> void:
	for r in WROWS:
		var d := {}
		for i in WF.size():
			d[WF[i]] = r[i]
		weapons[r[0]] = d
		weapon_order.append(r[0])
	for r in MROWS:
		masks[r[0]] = {"id": r[0], "ru": r[1], "en": r[2], "desc": r[3], "ab": r[4], "mods": r[5],
			"c": r[6], "a": r[7], "ears": r[8], "pat": r[9], "unlock": r[10]}
		masks_order.append(r[0])

func weapon(id: String) -> Dictionary:
	return weapons.get(id, weapons["fists"])

func mask(id: String) -> Dictionary:
	return masks.get(id, masks["fox"])

func mask_mods(id: String) -> Dictionary:
	return mask(id)["mods"]

func theme(id: String) -> Dictionary:
	return THEMES.get(id, THEMES["club"])

func unlock_text(cond: String) -> String:
	if cond == "start":
		return Settings.L("Доступна сразу", "Available from start")
	var p := cond.split(":")
	return "%s: %s" % [COND_RU.get(p[0], p[0]), p[1]]
