extends Node
## Единый хаб ввода: клавиатура/мышь + сенсорные кнопки.

signal pressed(action: String)

var use_touch := false
var touch_move := Vector2.ZERO
var touch_aim_active := false
var touch_aim_pos := Vector2.ZERO
var t_attack := false
var t_run := false
var t_aim := false
var m_attack := false
var kb_move := Vector2.ZERO
var attack := false
var run := false
var aim_lock := false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	refresh()
	Settings.changed.connect(refresh)

func refresh() -> void:
	var m := int(Settings.data["touch_mode"])
	use_touch = m == 1 or (m == 0 and (DisplayServer.is_touchscreen_available() or OS.has_feature("mobile")))

func get_move() -> Vector2:
	if touch_move.length() > 0.05:
		return touch_move
	return kb_move

func clear_touch() -> void:
	touch_move = Vector2.ZERO
	touch_aim_active = false
	t_attack = false
	t_run = false
	t_aim = false

func _k(code: Key) -> float:
	return 1.0 if Input.is_physical_key_pressed(code) else 0.0

func _process(_dt: float) -> void:
	var v := Vector2(_k(KEY_D) + _k(KEY_RIGHT) - _k(KEY_A) - _k(KEY_LEFT), _k(KEY_S) + _k(KEY_DOWN) - _k(KEY_W) - _k(KEY_UP))
	kb_move = v.limit_length(1.0)
	attack = t_attack or m_attack
	run = t_run or Input.is_physical_key_pressed(KEY_SHIFT)
	aim_lock = t_aim or Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT)

func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventKey and e.pressed and not e.echo:
		match e.physical_keycode:
			KEY_E: pressed.emit("interact")
			KEY_F: pressed.emit("pickup")
			KEY_Q: pressed.emit("swap")
			KEY_SPACE: pressed.emit("melee")
			KEY_R: pressed.emit("reload")
			KEY_ESCAPE: pressed.emit("pause")
	elif e is InputEventMouseButton and not use_touch and e.button_index == MOUSE_BUTTON_LEFT:
		m_attack = e.pressed
		if e.pressed:
			pressed.emit("tap")
