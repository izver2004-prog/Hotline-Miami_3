extends Node2D
## Строит уровень из .lvl, спавнит объекты, считает очки/комбо, ведёт состояние уровня.

const TS := 32
const ENEMY_KEYS := {"e": "thug", "g": "gunman", "s": "shotgunner", "r": "rifleman", "h": "heavy", "p": "patrol", "k": "runner"}
const WEAPON_KEYS := {"1": "pistol", "2": "shotgun", "3": "smg", "4": "bat", "5": "knife", "6": "throwing_knife",
	"7": "katana", "8": "rifle", "9": "grenade", "0": "crowbar"}
const PlayerScript := preload("res://characters/player.gd")
const EnemyScript := preload("res://characters/enemy.gd")
const BulletScript := preload("res://weapons/bullet.gd")
const PickupScript := preload("res://weapons/pickup.gd")
const DoorScript := preload("res://scripts/door.gd")
const HudScript := preload("res://ui/hud.gd")
const TouchScript := preload("res://ui/touch_controls.gd")

var meta := {}
var rows: Array = []
var W := 0
var H := 0
var theme_id := "club"
var astar := AStarGrid2D.new()
var player
var enemies: Array = []
var hud
var cam: Camera2D
var decals: Node2D
var pickups: Node2D
var actors: Node2D
var bullets: Node2D
var glow_layer: Node2D
var start_pos := Vector2.ZERO
var exit_pos = null
var weapon_keys := WEAPON_KEYS.duplicate()
var enemy_spawns: Array = []
var weapon_spawns: Array = []
var glows: Array = []

var state := "play"   # play, cleared, dead, done
var score := 0
var combo := 0
var combo_t := 0.0
var kills := 0
var total := 0
var elapsed := 0.0
var shake := 0.0
var decal_cap := 300
var cleared_t := 0.0

func _ready() -> void:
	get_tree().root.content_scale_factor = 1.0
	get_tree().paused = false
	if Game.current_level == "":
		Game.current_level = Game.first_level()
	meta = Game.parse_level(Game.current_level)
	rows = meta.get("rows", [])
	H = rows.size()
	for r in rows:
		W = maxi(W, str(r).length())
	theme_id = str(meta.get("theme", "club"))
	for k in meta:
		if str(k).begins_with("key_"):
			weapon_keys[str(k).substr(4)] = meta[k]
	decal_cap = [0, 80, 300][clampi(int(Settings.data["fx_quality"]), 0, 2)]
	decals = Node2D.new()
	pickups = Node2D.new()
	actors = Node2D.new()
	actors.z_index = 2
	bullets = Node2D.new()
	bullets.z_index = 3
	glow_layer = Node2D.new()
	glow_layer.z_index = 4
	var cm := CanvasItemMaterial.new()
	cm.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	glow_layer.material = cm
	for n in [decals, pickups, actors, bullets, glow_layer]:
		add_child(n)
	_build()
	var mask_id: String = str(Game.save.get("mask", "fox"))
	if not Game.save["masks"].has(mask_id):
		mask_id = "fox"
	player = CharacterBody2D.new()
	player.set_script(PlayerScript)
	player.position = start_pos
	actors.add_child(player)
	player.setup(self, mask_id, str(meta.get("weapon", "")))
	for es in enemy_spawns:
		var e := CharacterBody2D.new()
		e.set_script(EnemyScript)
		e.position = es[1]
		actors.add_child(e)
		e.setup(self, ENEMY_KEYS[es[0]])
		enemies.append(e)
	total = enemies.size()
	for ws in weapon_spawns:
		spawn_pickup(ws[0], ws[1], -1)
	cam = Camera2D.new()
	cam.position_smoothing_enabled = true
	cam.position_smoothing_speed = 10.0
	cam.zoom = Vector2.ONE * 1.5 * float(Settings.data["pixel_scale"])
	cam.limit_left = -96
	cam.limit_top = -96
	cam.limit_right = W * TS + 96
	cam.limit_bottom = H * TS + 96
	add_child(cam)
	cam.global_position = start_pos
	cam.make_current()
	hud = CanvasLayer.new()
	hud.set_script(HudScript)
	add_child(hud)
	hud.setup(self)
	if Inp.use_touch:
		var tl := CanvasLayer.new()
		tl.layer = 9
		var tc := Control.new()
		tc.set_script(TouchScript)
		tl.add_child(tc)
		add_child(tl)
	Audio.play_level_music(str(meta.get("music", "")))
	Inp.pressed.connect(_on_input)
	hud.message(str(meta.get("name", "")), 2.0)

func _at(x: int, y: int) -> String:
	if y < 0 or y >= H:
		return " "
	var r: String = rows[y]
	if x < 0 or x >= r.length():
		return " "
	return r[x]

func _solid_at(x: int, y: int) -> bool:
	return _at(x, y) in "# TC"

func _build() -> void:
	astar.region = Rect2i(0, 0, maxi(W, 1), maxi(H, 1))
	astar.cell_size = Vector2(TS, TS)
	astar.offset = Vector2(TS / 2.0, TS / 2.0)
	astar.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	astar.update()
	for y in H:
		var x := 0
		while x < W:
			var ch := _at(x, y)
			var pos := Vector2(x * TS + TS / 2.0, y * TS + TS / 2.0)
			if ch == "#":
				var x2 := x
				while _at(x2 + 1, y) == "#":
					x2 += 1
				_add_block(Vector2((x + x2 + 1) * TS / 2.0, pos.y), Vector2((x2 - x + 1) * TS, TS))
				for xx in range(x, x2 + 1):
					astar.set_point_solid(Vector2i(xx, y), true)
				x = x2 + 1
				continue
			elif ch == " ":
				astar.set_point_solid(Vector2i(x, y), true)
			elif ch == "T" or ch == "C":
				_add_block(pos, Vector2(TS - 4, TS - 4))
				astar.set_point_solid(Vector2i(x, y), true)
			elif ch == "D":
				var d := StaticBody2D.new()
				d.set_script(DoorScript)
				d.position = pos
				add_child(d)
				d.setup(self, _solid_at(x - 1, y) and _solid_at(x + 1, y), theme_id)
			elif ch == "@":
				start_pos = pos
			elif ch == "X":
				exit_pos = pos
			elif ch == "*":
				glows.append(pos)
			elif ENEMY_KEYS.has(ch):
				enemy_spawns.append([ch, pos])
			elif weapon_keys.has(ch):
				weapon_spawns.append([str(weapon_keys[ch]), pos])
			x += 1
	if int(Settings.data["fx_quality"]) >= 1:
		var neon := Color(Data.theme(theme_id)["neon"])
		for g in glows:
			var s := Sprite2D.new()
			s.texture = Art.glow_tex()
			s.position = g
			s.scale = Vector2(4, 4)
			s.modulate = Color(neon, 0.55)
			glow_layer.add_child(s)

func _add_block(center: Vector2, size: Vector2) -> void:
	var b := StaticBody2D.new()
	b.collision_layer = 1
	b.collision_mask = 0
	b.position = center
	var cs := CollisionShape2D.new()
	var rs := RectangleShape2D.new()
	rs.size = size
	cs.shape = rs
	b.add_child(cs)
	add_child(b)

func _draw() -> void:
	var s := float(TS)
	var wt := Art.wall_tex(theme_id)
	var wf := Art.wall_front_tex(theme_id)
	for y in H:
		for x in W:
			var ch := _at(x, y)
			if ch == " " or ch == "#":
				continue
			var ft := 1 if ch == "," else (2 if ch == "_" else 0)
			draw_texture_rect(Art.floor_tex(theme_id, ft), Rect2(x * s, y * s, s, s), false)
			if ch == "T" or ch == "C":
				draw_texture_rect(Art.furn_tex(ch, theme_id), Rect2(x * s, y * s, s, s), false)
			if ch == "X":
				draw_rect(Rect2(x * s + 4, y * s + 4, s - 8, s - 8), Color(0.2, 1, 0.4, 0.5))
	for y in H:
		for x in W:
			if _at(x, y) == "#":
				draw_texture_rect(wt, Rect2(x * s, y * s, s, s), false)
				if _at(x, y + 1) != "#" and _at(x, y + 1) != " ":
					draw_texture_rect(wf, Rect2(x * s, (y + 1) * s, s, 16), false)

# ---------- API для сущностей ----------
func has_los(a: Vector2, b: Vector2) -> bool:
	var q := PhysicsRayQueryParameters2D.create(a, b, 1)
	return get_world_2d().direct_space_state.intersect_ray(q).is_empty()

func find_path(a: Vector2, b: Vector2) -> PackedVector2Array:
	var ca := Vector2i(int(a.x / TS), int(a.y / TS))
	var cb := Vector2i(int(b.x / TS), int(b.y / TS))
	if not astar.is_in_boundsv(ca) or not astar.is_in_boundsv(cb) or astar.is_point_solid(cb) or astar.is_point_solid(ca):
		return PackedVector2Array([b])
	var p := astar.get_point_path(ca, cb)
	if p.is_empty():
		return PackedVector2Array([b])
	return p

func make_noise(pos: Vector2, radius: float) -> void:
	if radius <= 0.0:
		return
	for e in enemies:
		if is_instance_valid(e) and e.state != "dead" and e.global_position.distance_to(pos) < radius:
			e.hear(pos)

func spawn_bullet(p: Dictionary) -> void:
	var b := Node2D.new()
	b.set_script(BulletScript)
	b.global_position = p["pos"]
	bullets.add_child(b)
	b.setup(self, p)

func spawn_pickup(id: String, pos: Vector2, ammo: int) -> void:
	var k := Node2D.new()
	k.set_script(PickupScript)
	k.position = pos
	pickups.add_child(k)
	k.setup(id, ammo)

func add_blood(pos: Vector2, dir: Vector2, big: bool) -> void:
	if decal_cap <= 0:
		return
	var n := 3 if big else 1
	for i in n:
		var s := Sprite2D.new()
		s.texture = Art.blood_tex(randi() % 3)
		s.position = pos + dir * randf_range(4, 26) * (i + 1) * 0.5 + Vector2(randf_range(-8, 8), randf_range(-8, 8))
		s.rotation = randf() * TAU
		s.scale = Vector2.ONE * randf_range(1.0, 2.0)
		decals.add_child(s)
	while decals.get_child_count() > decal_cap:
		decals.get_child(0).queue_free()
		decals.remove_child(decals.get_child(0))

func shake_cam(a: float) -> void:
	shake = maxf(shake, a * float(Settings.data["fx_intensity"]))

func explode(pos: Vector2, r: float) -> void:
	Audio.play("explode")
	shake_cam(14.0)
	make_noise(pos, 500.0)
	var s := Sprite2D.new()
	s.texture = Art.glow_tex()
	s.position = pos
	s.scale = Vector2.ONE * r / 14.0
	s.modulate = Color(1, 0.6, 0.2, 1)
	glow_layer.add_child(s)
	var tw := create_tween()
	tw.tween_property(s, "modulate:a", 0.0, 0.4)
	tw.tween_callback(s.queue_free)
	for e in enemies.duplicate():
		if is_instance_valid(e) and e.state != "dead" and e.global_position.distance_to(pos) < r:
			e.hit(5, (e.global_position - pos).normalized(), "throw")
	if player.alive and player.global_position.distance_to(pos) < r:
		player.hit(5, (player.global_position - pos).normalized(), "explosion")

func on_enemy_killed(e, how: String) -> void:
	kills += 1
	combo += 1
	var mods: Dictionary = player.mods
	combo_t = 2.5 + float(mods.get("combo", 0.0))
	var mult: int = clampi(combo, 1, 8)
	var pts := float(e.kind["score"]) * float(mult) * float(mods.get("score", 1.0))
	if how == "melee" or how == "fists":
		pts *= 1.5
		Game.add_stat("melee_kills")
	elif how == "throw":
		Game.add_stat("throw_kills")
	score += int(pts)
	Game.add_stat("kills")
	if combo > Game.stat("max_combo"):
		Game.save["stats"]["max_combo"] = combo
	hud.popup("+%d  x%d" % [int(pts), mult], e.global_position, UI.YEL)
	Game.check_unlocks()
	if kills >= total and state == "play":
		state = "cleared"
		if exit_pos != null:
			hud.message(Settings.L("ЗАЧИСТКА! ВЕРНИСЬ К ВЫХОДУ", "CLEAR! RETURN TO EXIT"), 4.0)
		else:
			cleared_t = 1.2

func on_player_died() -> void:
	if state == "dead" or state == "done":
		return
	state = "dead"
	combo = 0
	Game.add_stat("deaths")
	Game.add_stat("shots", player.stats_shots)
	Game.write_save()
	Audio.play("death")
	shake_cam(14.0)
	if Settings.data["vibration"]:
		Input.vibrate_handheld(150)
	hud.show_dead()

func finish() -> void:
	if state == "done":
		return
	state = "done"
	var par_time := float(meta.get("par_time", 90.0))
	var bonus := int(maxf(0.0, par_time - elapsed)) * 10
	score += bonus
	Game.add_stat("shots", player.stats_shots)
	Game.add_stat("playtime", elapsed)
	var res := {"score": score, "kills": kills, "total": total, "time": elapsed, "bonus": bonus,
		"acc": float(player.stats_hits) / maxf(1.0, float(player.stats_shots))}
	res = Game.finish_level(res)
	Audio.play("level_end")
	hud.show_result(res)

func _on_input(a: String) -> void:
	if a == "tap" and state == "dead":
		restart()
	elif a == "reload" and state == "dead":
		restart()

func restart() -> void:
	Fx.change_scene("res://scenes/game.tscn")

func _process(dt: float) -> void:
	if state == "play" or state == "cleared":
		elapsed += dt
	if combo_t > 0.0:
		combo_t -= dt
		if combo_t <= 0.0:
			combo = 0
	if cleared_t > 0.0:
		cleared_t -= dt
		if cleared_t <= 0.0:
			finish()
	if state == "cleared" and exit_pos != null and player.alive and player.global_position.distance_to(exit_pos) < 28.0:
		finish()
	if is_instance_valid(player):
		var off := Vector2.ZERO
		if player.alive:
			off = Vector2.from_angle(player.aim_angle) * 50.0
		cam.global_position = player.global_position + off
	shake = maxf(0.0, shake - dt * 30.0)
	cam.offset = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake
