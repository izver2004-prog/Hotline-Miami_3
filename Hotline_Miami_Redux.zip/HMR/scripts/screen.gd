extends Control
## База для экранов меню: фон, масштаб UI, хелперы страницы.

const BackdropScript := preload("res://ui/backdrop.gd")

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	Settings.apply_scale()
	var bg := Control.new()
	bg.set_script(BackdropScript)
	add_child(bg)
	Audio.play_menu_music()
	build()

func build() -> void:
	pass

func go(path: String) -> void:
	Fx.change_scene(path)

func _exit_tree() -> void:
	Settings.save_settings()

## Страница: заголовок + кнопка «Назад» + прокручиваемое тело. Возвращает VBox тела.
func page(title: String, back_to: String = "res://scenes/main_menu.tscn") -> VBoxContainer:
	var m := MarginContainer.new()
	m.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for s in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + s, 24)
	add_child(m)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	m.add_child(v)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 20)
	v.add_child(top)
	top.add_child(UI.btn("< " + Settings.L("Назад", "Back"), func(): go(back_to), UI.YEL, 160.0))
	var t := UI.lbl(title, 40, UI.PINK)
	t.add_theme_constant_override("outline_size", 8)
	t.add_theme_color_override("font_outline_color", Color(1, 0.18, 0.58, 0.35))
	top.add_child(t)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(sc)
	var body := VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 12)
	sc.add_child(body)
	return body
