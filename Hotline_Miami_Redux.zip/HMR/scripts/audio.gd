extends Node
## SFX синтезируются в коде. Музыку кладите в res://music/ (или user://music/): .ogg .mp3 .wav
## menu_*.ext — меню; остальное — уровни. В .lvl можно указать music=имя_файла_без_расширения.

const RATE := 22050

var sfx := {}
var players: Array = []
var pi := 0
var music: AudioStreamPlayer
var tracks: Array = []
var playlist: Array = []
var idx := 0
var current_key := ""
var last_step := 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for b in ["Music", "SFX", "UI"]:
		if AudioServer.get_bus_index(b) < 0:
			AudioServer.add_bus()
			var i := AudioServer.bus_count - 1
			AudioServer.set_bus_name(i, b)
			AudioServer.set_bus_send(i, "Master")
	_build_sfx()
	for i in 14:
		var p := AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	music = AudioStreamPlayer.new()
	music.bus = "Music"
	music.finished.connect(_next)
	add_child(music)
	scan_music()
	Settings.apply()

func _make(dur: float, f: Callable) -> AudioStreamWAV:
	var n := int(dur * RATE)
	var b := PackedByteArray()
	b.resize(n * 2)
	for i in n:
		var v: float = clampf(float(f.call(float(i) / RATE, dur)), -1.0, 1.0)
		b.encode_s16(i * 2, int(v * 30000.0))
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = RATE
	s.stereo = false
	s.data = b
	return s

func _build_sfx() -> void:
	var st := [0.0]
	sfx["shot"] = _make(0.25, func(t, _d): return randf_range(-1, 1) * exp(-t * 26.0) * 0.8 + sin(t * TAU * (170.0 - t * 300.0)) * exp(-t * 18.0) * 0.8)
	sfx["smg"] = _make(0.12, func(t, _d): return randf_range(-1, 1) * exp(-t * 40.0) * 0.7 + sin(t * TAU * 230.0) * exp(-t * 35.0) * 0.6)
	sfx["shotgun"] = _make(0.5, func(t, _d): return randf_range(-1, 1) * exp(-t * 8.0) * 0.9 + sin(t * TAU * 80.0) * exp(-t * 10.0) * 0.8)
	sfx["swing"] = _make(0.18, func(t, d):
		st[0] += (randf_range(-1, 1) - st[0]) * 0.15
		return st[0] * sin(PI * t / d) * 1.4)
	sfx["hit"] = _make(0.16, func(t, _d): return randf_range(-1, 1) * exp(-t * 28.0) * 0.6 + sin(t * TAU * 120.0) * exp(-t * 30.0) * 0.9)
	sfx["kill"] = _make(0.3, func(t, _d): return sin(t * TAU * (220.0 - t * 400.0)) * exp(-t * 9.0) * 0.8 + randf_range(-1, 1) * exp(-t * 22.0) * 0.5)
	sfx["step"] = _make(0.07, func(t, _d):
		st[0] += (randf_range(-1, 1) - st[0]) * 0.25
		return st[0] * exp(-t * 55.0) * 0.5)
	sfx["door"] = _make(0.3, func(t, _d): return sin(t * TAU * 70.0) * exp(-t * 14.0) * 0.9 + randf_range(-1, 1) * exp(-t * 35.0) * 0.4)
	sfx["pickup"] = _make(0.14, func(t, _d): return sin(t * TAU * (600.0 + t * 4000.0)) * exp(-t * 14.0) * 0.5)
	sfx["swap"] = _make(0.08, func(t, _d): return sin(t * TAU * 300.0) * exp(-t * 50.0) * 0.5 + randf_range(-1, 1) * exp(-t * 70.0) * 0.3)
	sfx["ui_click"] = _make(0.07, func(t, _d): return sign(sin(t * TAU * 880.0)) * exp(-t * 45.0) * 0.35)
	sfx["ui_back"] = _make(0.07, func(t, _d): return sign(sin(t * TAU * 440.0)) * exp(-t * 45.0) * 0.35)
	sfx["reload"] = _make(0.3, func(t, _d): return randf_range(-1, 1) * (exp(-t * 90.0) + exp(-(t - 0.14) * 90.0) * float(t > 0.14)) * 0.5)
	sfx["death"] = _make(0.8, func(t, _d): return sin(t * TAU * (240.0 - t * 200.0)) * exp(-t * 3.5) * 0.7 + randf_range(-1, 1) * exp(-t * 12.0) * 0.3)
	sfx["explode"] = _make(0.9, func(t, _d):
		st[0] += (randf_range(-1, 1) - st[0]) * 0.1
		return st[0] * exp(-t * 3.5) * 2.2 + sin(t * TAU * 50.0) * exp(-t * 5.0) * 0.8)
	sfx["glass"] = _make(0.35, func(t, _d): return randf_range(-1, 1) * exp(-t * 12.0) * 0.45)
	sfx["level_end"] = _make(0.7, func(t, _d):
		var f := 440.0 if t < 0.2 else (554.0 if t < 0.4 else 659.0)
		return sign(sin(t * TAU * f)) * exp(-fmod(t, 0.2) * 6.0) * 0.3)

func play(name: String, vol: float = 1.0, pitch_var: float = 0.06) -> void:
	if not sfx.has(name):
		return
	var p: AudioStreamPlayer = players[pi]
	pi = (pi + 1) % players.size()
	p.stream = sfx[name]
	p.bus = "UI" if name.begins_with("ui_") else "SFX"
	p.volume_db = linear_to_db(maxf(0.01, vol))
	p.pitch_scale = 1.0 + randf_range(-pitch_var, pitch_var)
	p.play()

func step() -> void:
	var now := Time.get_ticks_msec() / 1000.0
	if now - last_step > 0.28:
		last_step = now
		play("step", 0.5, 0.15)

# ---------- музыка ----------
func scan_music() -> void:
	tracks.clear()
	_scan_dir("res://music", true)
	_scan_dir("user://music", false)

func _scan_dir(path: String, is_res: bool) -> void:
	var d := DirAccess.open(path)
	if d == null:
		return
	for dn in d.get_directories():
		_scan_dir(path + "/" + str(dn), is_res)
	for f in d.get_files():
		var n: String = str(f).trim_suffix(".import").trim_suffix(".remap")
		if n.get_extension().to_lower() in ["ogg", "mp3", "wav"]:
			var full := path + "/" + n
			if not tracks.has(full):
				tracks.append(full)

func play_menu_music() -> void:
	_play_list(tracks.filter(func(p): return str(p).get_file().begins_with("menu")), "menu")

func play_level_music(wanted: String) -> void:
	var l: Array = tracks.filter(func(p): return str(p).get_file().get_basename() == wanted)
	if l.is_empty():
		l = tracks.filter(func(p): return not str(p).get_file().begins_with("menu"))
	_play_list(l, "lvl:" + wanted)

func _play_list(list: Array, key: String) -> void:
	if list.is_empty():
		list = tracks
	if list.is_empty():
		music.stop()
		return
	if current_key == key and music.playing:
		return
	current_key = key
	playlist = list.duplicate()
	playlist.shuffle()
	idx = 0
	_next()

func _next() -> void:
	if playlist.is_empty():
		return
	var p: String = playlist[idx % playlist.size()]
	idx += 1
	var s = _load_stream(p)
	if s:
		music.stream = s
		music.play()

func _load_stream(p: String):
	if p.begins_with("res://"):
		return load(p)
	var ext := p.get_extension().to_lower()
	if ext == "ogg":
		return AudioStreamOggVorbis.load_from_file(p)
	if ext == "mp3":
		var m := AudioStreamMP3.new()
		m.data = FileAccess.get_file_as_bytes(p)
		return m
	return null
