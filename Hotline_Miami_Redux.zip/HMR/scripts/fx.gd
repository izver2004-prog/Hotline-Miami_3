extends CanvasLayer
## Глобальный VHS/цветовой фильтр и плавные переходы сцен.

var rect: ColorRect
var fade: ColorRect
var mat: ShaderMaterial
var t := 0.0
var busy := false

func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	rect = ColorRect.new()
	rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mat = ShaderMaterial.new()
	mat.shader = load("res://assets/shaders/vhs.gdshader")
	rect.material = mat
	add_child(rect)
	fade = ColorRect.new()
	fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fade.color = Color(0, 0, 0, 0)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(fade)
	Settings.changed.connect(refresh)
	refresh()

func refresh() -> void:
	var d: Dictionary = Settings.data
	rect.visible = int(d["fx_quality"]) > 0
	mat.set_shader_parameter("vhs", float(d["vhs"]))
	mat.set_shader_parameter("fx", float(d["fx_intensity"]))
	mat.set_shader_parameter("quality", int(d["fx_quality"]))
	mat.set_shader_parameter("brightness", float(d["brightness"]))
	mat.set_shader_parameter("contrast", float(d["contrast"]))
	mat.set_shader_parameter("filter_mode", int(d["color_filter"]))

func _process(dt: float) -> void:
	t += dt
	mat.set_shader_parameter("time_s", t)

func change_scene(path: String) -> void:
	if busy:
		return
	busy = true
	fade.mouse_filter = Control.MOUSE_FILTER_STOP
	var tw := create_tween()
	tw.tween_property(fade, "color:a", 1.0, 0.16)
	await tw.finished
	get_tree().paused = false
	get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	var tw2 := create_tween()
	tw2.tween_property(fade, "color:a", 0.0, 0.2)
	await tw2.finished
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	busy = false
