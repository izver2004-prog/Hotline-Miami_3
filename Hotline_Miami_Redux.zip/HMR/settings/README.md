Настройки и раскладка сенсорных кнопок хранятся в user://settings.json (см. scripts/settings.gd).
