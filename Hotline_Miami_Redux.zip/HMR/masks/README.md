Данные 20 масок: scripts/data.gd (MROWS). Иконки: scripts/art.gd (mask_icon).
