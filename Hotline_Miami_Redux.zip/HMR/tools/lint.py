#!/usr/bin/env python3
"""Статическая проверка (без Godot): пути res://, отступы, скобки, подозрительные ':=' на Variant."""
import re, os, sys
root = os.getcwd(); bad = 0
def err(m):
    global bad; bad += 1; print("ERR", m)
for dp, dn, fn in os.walk(root):
    if ".git" in dp or "build" in dp: continue
    for f in fn:
        p = os.path.join(dp, f)
        if f.endswith((".gd", ".tscn", ".cfg", ".godot", ".gdshader")):
            t = open(p, encoding="utf-8").read()
            for m in re.finditer(r'res://([^"\')\s%]+)', t):
                rp = m.group(1)
                if not os.path.exists(os.path.join(root, rp)): err(f"{p}: missing res://{rp}")
        if f.endswith(".gd"):
            t = open(p, encoding="utf-8").read()
            if t.count("(") != t.count(")") or t.count("[") != t.count("]") or t.count("{") != t.count("}"):
                err(f"{p}: unbalanced brackets")
            for i, l in enumerate(t.split("\n"), 1):
                if l.startswith(" "): err(f"{p}:{i}: space indent")
                if re.search(r'^\s*(var|const)\s+\w+\s*:=\s*[\w\.]+\[".*?"\]\s*$', l): err(f"{p}:{i}: ':=' from dict index (Variant): {l.strip()}")
print("lint errors:", bad); sys.exit(1 if bad else 0)
