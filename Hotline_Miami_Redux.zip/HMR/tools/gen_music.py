#!/usr/bin/env python3
"""Генерирует ТЕСТОВЫЕ синтвейв-лупы в music/test/. Удалите папку, когда добавите свою музыку."""
import numpy as np, wave, os
SR = 22050
def saw(f, t): return 2.0 * ((f * t) % 1.0) - 1.0
def sq(f, t): return np.sign(np.sin(2 * np.pi * f * t))
def mtof(m): return 440.0 * 2 ** ((m - 69) / 12.0)
def lp(x, n):
    k = np.ones(n) / n
    return np.convolve(x, k, mode="same")
def track(name, bpm, root, prog, lead_pat, seed):
    rng = np.random.default_rng(seed)
    beat = 60.0 / bpm
    bars = 8
    n = int(SR * beat * 4 * bars)
    out = np.zeros(n)
    t_all = np.arange(n) / SR
    def add(start, sig):
        i = int(start * SR); e = min(n, i + len(sig))
        if i < n: out[i:e] += sig[: e - i]
    for b in range(bars):
        chord = prog[b % len(prog)]
        bar_t = b * beat * 4
        for s in range(16):  # 16th grid
            t0 = bar_t + s * beat / 4
            if s % 4 == 0:  # kick
                tt = np.arange(int(SR * 0.25)) / SR
                add(t0, np.sin(2 * np.pi * (45 + 110 * np.exp(-tt * 28)) * tt) * np.exp(-tt * 9) * 0.9)
            if s % 4 == 2:  # hat
                tt = np.arange(int(SR * 0.05)) / SR
                add(t0, rng.uniform(-1, 1, len(tt)) * np.exp(-tt * 90) * 0.18)
            if s % 8 == 4:  # snare
                tt = np.arange(int(SR * 0.2)) / SR
                add(t0, (rng.uniform(-1, 1, len(tt)) * 0.5 + np.sin(2 * np.pi * 190 * tt) * 0.4) * np.exp(-tt * 18) * 0.5)
            tt = np.arange(int(SR * beat / 4 * 0.95)) / SR
            add(t0, saw(mtof(root + chord[0] - 24), tt) * np.exp(-tt * 6) * 0.28)  # bass 16ths
            if lead_pat[s % len(lead_pat)]:
                note = root + chord[(s // 2) % 3] + 12 * lead_pat[s % len(lead_pat)]
                tl = np.arange(int(SR * beat / 2)) / SR
                add(t0, (sq(mtof(note), tl) * 0.5 + saw(mtof(note) * 1.005, tl) * 0.5) * np.exp(-tl * 5) * 0.16)
        tp = np.arange(int(SR * beat * 4)) / SR
        pad = sum(saw(mtof(root + c), tp) for c in chord) / 3
        add(bar_t, lp(pad, 40) * (0.5 - 0.5 * np.cos(2 * np.pi * tp / (beat * 4))) * 0.35)
    out /= max(1e-6, np.abs(out).max()) / 0.85
    os.makedirs("music/test", exist_ok=True)
    with wave.open(f"music/test/{name}.wav", "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((out * 32000).astype(np.int16).tobytes())
Am = [[0, 3, 7], [-4, 0, 3], [3, 7, 10], [-2, 2, 5]]
track("menu_test", 96, 57, Am, [0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0], 1)
track("lvl_test_drive", 128, 57, Am, [1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1], 2)
track("lvl_test_chase", 150, 52, [[0, 3, 7], [5, 8, 12], [3, 7, 10], [7, 10, 14]], [1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 2, 0], 3)
print("ok")
