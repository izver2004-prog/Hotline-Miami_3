#!/usr/bin/env python3
"""Генерирует ТЕСТОВЫЕ уровни levels/test/*.lvl и проверяет достижимость. Файлы можно править вручную."""
import os
from collections import deque

class G:
    def __init__(s, w, h): s.w, s.h = w, h; s.g = [[' '] * w for _ in range(h)]
    def room(s, x, y, w, h, fl='.'):
        for j in range(y, y + h):
            for i in range(x, x + w):
                s.g[j][i] = '#' if (i in (x, x + w - 1) or j in (y, y + h - 1)) else fl
    def fill(s, x, y, w, h, c):
        for j in range(y, y + h):
            for i in range(x, x + w): s.g[j][i] = c
    def put(s, x, y, c): s.g[y][x] = c
    def text(s): return "\n".join("".join(r) for r in s.g)

def save(name, meta, g):
    head = "\n".join(f"{k}={v}" for k, v in meta.items())
    open(f"levels/test/{name}.lvl", "w").write(head + "\n---\n" + g.text() + "\n")
    validate(name, g)

def validate(name, g):
    start = [(x, y) for y in range(g.h) for x in range(g.w) if g.g[y][x] == '@']
    assert len(start) == 1, name + ": need exactly one @"
    seen = {start[0]}; q = deque(start)
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < g.w and 0 <= ny < g.h and (nx, ny) not in seen and g.g[ny][nx] not in '# TC':
                seen.add((nx, ny)); q.append((nx, ny))
    bad = [(x, y, g.g[y][x]) for y in range(g.h) for x in range(g.w)
           if g.g[y][x] not in '# TC.,_*' and (x, y) not in seen]
    # door tiles must be passable and every interactive object reachable
    assert not bad, f"{name}: unreachable {bad}"
    en = sum(1 for r in g.g for c in r if c in 'egsrhpk')
    print(f"{name}: {g.w}x{g.h}, enemies={en}, OK")

os.makedirs("levels/test", exist_ok=True)

# 1. CLUB
g = G(34, 20)
g.room(0, 0, 8, 12); g.room(7, 0, 20, 12, ','); g.room(26, 0, 8, 12); g.room(0, 11, 34, 9, '_')
g.put(7, 5, 'D'); g.put(26, 5, 'D'); g.put(16, 11, 'D'); g.put(3, 11, 'D'); g.put(30, 11, 'D')
for p in ((10, 3), (10, 8), (14, 6), (21, 4), (21, 8)): g.put(*p, 'T')
for p in ((12, 2), (18, 9), (24, 2), (3, 8)): g.put(*p, '*')
g.put(2, 2, '@'); g.put(5, 8, '5'); g.put(14, 2, '1'); g.put(28, 9, '2'); g.put(6, 14, '3')
for p, c in (((20, 3), 'g'), ((12, 7), 'e'), ((23, 8), 'g'), ((30, 3), 's'), ((29, 8), 'e'), ((10, 15), 'r'), ((25, 15), 'e')): g.put(*p, c)
for p in ((14, 14), (15, 14), (22, 16), (23, 16)): g.put(*p, 'C')
save("01_neon_pulse", {"name": "Neon Pulse", "theme": "club", "par_time": 90, "music": "lvl_test_drive"}, g)

# 2. OFFICE
g = G(40, 24)
g.room(0, 9, 40, 6, ',')
xs = [0, 10, 20, 30]
for i, x in enumerate(xs):
    g.room(x, 0, 11 if x < 30 else 10, 10); g.room(x, 14, 11 if x < 30 else 10, 10)
    g.put(x + 5, 9, 'D'); g.put(x + 5, 14, 'D')
    g.put(x + 3, 3, 'T'); g.put(x + 4, 3, 'T'); g.put(x + 6, 19, 'T'); g.put(x + 7, 19, 'T')
g.put(1, 11, '@'); g.put(15, 11, '*'); g.put(25, 11, '*'); g.put(35, 12, '*')
g.put(12, 3, '4'); g.put(24, 5, '1'); g.put(35, 20, '3'); g.put(5, 20, '0'); g.put(16, 18, '6')
for p, c in (((6, 6), 'e'), ((16, 6), 'g'), ((26, 3), 'e'), ((36, 6), 's'), ((7, 17), 'g'), ((17, 21), 'e'), ((26, 18), 'k'), ((36, 17), 'r'), ((20, 12), 'p'), ((30, 11), 'g')): g.put(*p, c)
save("02_night_shift", {"name": "Night Shift", "theme": "office", "par_time": 120, "music": "lvl_test_chase"}, g)

# 3. APARTMENT
g = G(30, 22)
g.room(0, 0, 12, 10, '.'); g.room(11, 0, 10, 10, '_'); g.room(20, 0, 10, 10, ','); g.room(0, 9, 30, 5, '.'); g.room(0, 13, 14, 9); g.room(13, 13, 17, 9, '_')
g.put(11, 5, 'D'); g.put(20, 5, 'D'); g.put(5, 9, 'D'); g.put(15, 9, 'D'); g.put(25, 9, 'D'); g.put(6, 13, 'D'); g.put(21, 13, 'D'); g.put(13, 17, 'D')
for p in ((3, 2), (4, 2), (15, 3), (16, 3), (24, 3), (3, 17), (18, 17), (19, 17)): g.put(*p, 'T')
g.put(14, 11, '@'); g.put(8, 5, '5'); g.put(26, 6, '1'); g.put(8, 18, '4'); g.put(27, 18, '2'); g.put(24, 11, '*')
for p, c in (((6, 6), 'k'), ((16, 6), 'e'), ((25, 4), 'g'), ((4, 11), 'p'), ((25, 11), 'e'), ((9, 17), 'g'), ((22, 19), 's')): g.put(*p, c)
save("03_block_seven", {"name": "Block 7", "theme": "apartment", "par_time": 100, "music": "lvl_test_drive"}, g)

# 4. WAREHOUSE (open)
g = G(44, 26)
g.room(0, 0, 44, 26, '.'); g.room(0, 0, 10, 8); g.room(34, 18, 10, 8)
g.put(9, 4, 'D'); g.put(34, 22, 'D')
for cx, cy in ((14, 4), (20, 8), (26, 4), (14, 14), (22, 14), (30, 10), (16, 20), (26, 20), (36, 8), (38, 14), (8, 14)):
    g.fill(cx, cy, 3, 2, 'C')
g.fill(10, 11, 1, 5, 'C') if False else None
g.put(3, 3, '@'); g.put(5, 6, '5'); g.put(24, 12, '7'); g.put(40, 22, '8'); g.put(12, 24, '1'); g.put(30, 14, '9'); g.put(36, 4, '6')
g.put(12, 12, '*'); g.put(32, 6, '*'); g.put(24, 22, '*')
for p, c in (((16, 6), 'g'), ((28, 7), 'p'), ((20, 11), 'e'), ((33, 13), 'r'), ((12, 17), 'h'), ((24, 17), 'g'), ((38, 11), 'h'), ((20, 23), 's'), ((40, 20), 'e'), ((6, 21), 'k'), ((34, 4), 'p')): g.put(*p, c)
save("04_dock_nine", {"name": "Dock 9", "theme": "warehouse", "par_time": 140, "music": "lvl_test_chase"}, g)

# 5. HOTEL
g = G(46, 26)
g.room(0, 10, 46, 6, '_'); g.room(16, 0, 14, 11, ','); g.room(16, 15, 14, 11, ',')
for i, x in enumerate((0, 9, 31, 38)):
    w = 10 if x != 38 else 8
    g.room(x, 0, w, 11); g.room(x, 15, w, 11)
    g.put(x + 4, 10, 'D'); g.put(x + 4, 15, 'D')
g.put(22, 10, 'D'); g.put(22, 15, 'D')
for p in ((20, 3), (21, 3), (24, 3), (25, 3), (20, 22), (21, 22), (24, 22), (25, 22), (4, 3), (13, 22), (35, 3), (41, 22)): g.put(*p, 'T')
g.put(2, 12, '@'); g.put(23, 12, '*'); g.put(12, 12, '*'); g.put(34, 12, '*')
g.put(4, 6, '5'); g.put(13, 5, '1'); g.put(23, 5, '2'); g.put(13, 20, '3'); g.put(35, 20, '7'); g.put(40, 6, '8'); g.put(23, 22, '9')
for p, c in (((5, 4), 'e'), ((13, 7), 'g'), ((22, 6), 'h'), ((26, 7), 's'), ((12, 18), 'k'), ((5, 21), 'g'), ((22, 19), 'r'), ((27, 22), 'h'), ((34, 5), 'p'), ((42, 5), 'g'), ((34, 21), 's'), ((41, 20), 'r'), ((20, 12), 'p'), ((30, 13), 'g'), ((38, 12), 'e')): g.put(*p, c)
save("05_grand_miami", {"name": "Grand Miami", "theme": "hotel", "par_time": 170, "music": "lvl_test_chase"}, g)
