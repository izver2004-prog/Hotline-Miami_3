shader_type canvas_item;

uniform sampler2D screen_tex : hint_screen_texture, filter_nearest, repeat_disable;
uniform float vhs = 0.6;
uniform float fx = 1.0;
uniform int quality = 2;
uniform float brightness = 1.0;
uniform float contrast = 1.1;
uniform int filter_mode = 0;
uniform float time_s = 0.0;

float rnd(vec2 p) {
	return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

void fragment() {
	vec2 uv = SCREEN_UV;
	float k = vhs * fx;
	uv.x += sin(uv.y * 60.0 + time_s * 3.0) * 0.0006 * k;
	vec3 col;
	if (quality >= 1) {
		float ab = 0.0022 * k;
		col.r = texture(screen_tex, uv + vec2(ab, 0.0)).r;
		col.g = texture(screen_tex, uv).g;
		col.b = texture(screen_tex, uv - vec2(ab, 0.0)).b;
	} else {
		col = texture(screen_tex, uv).rgb;
	}
	if (quality >= 2) {
		col *= 1.0 - 0.14 * k * (0.5 + 0.5 * sin(FRAGCOORD.y * 3.14159));
		col += (rnd(uv * 900.0 + time_s) - 0.5) * 0.07 * k;
		float roll = smoothstep(0.0, 0.02, abs(fract(uv.y - time_s * 0.05) - 0.5) - 0.48);
		col += vec3(0.04 * k) * (1.0 - roll);
	}
	vec2 d = SCREEN_UV - vec2(0.5);
	col *= 1.0 - dot(d, d) * 0.8 * fx;
	float lum = dot(col, vec3(0.299, 0.587, 0.114));
	if (filter_mode == 1) col = mix(col, vec3(lum) * vec3(1.2, 0.45, 1.0), 0.6);
	else if (filter_mode == 2) col = mix(col, vec3(lum) * vec3(0.4, 1.0, 1.2), 0.6);
	else if (filter_mode == 3) col = mix(col, vec3(lum) * vec3(1.2, 0.85, 0.5), 0.7);
	else if (filter_mode == 4) col = vec3(lum);
	col = (col - 0.5) * contrast + 0.5;
	col *= brightness;
	COLOR = vec4(col, 1.0);
}
