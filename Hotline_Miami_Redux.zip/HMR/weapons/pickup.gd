extends Node2D
## Оружие на полу. Подбирается кнопкой «подбор».

var id := "pistol"
var ammo := -1
var t := 0.0

func setup(wid: String, am: int) -> void:
	id = wid
	ammo = am
	add_to_group("pickups")
	rotation = randf() * TAU
	var s := Sprite2D.new()
	s.texture = Art.weapon_tex(wid)
	s.scale = Vector2(2, 2)
	add_child(s)

func _process(dt: float) -> void:
	t += dt
	queue_redraw()

func _draw() -> void:
	var a := 0.35 + 0.25 * sin(t * 4.0)
	draw_arc(Vector2.ZERO, 14.0, 0, TAU, 20, Color(0.0, 0.94, 1.0, a), 2.0)
