extends Node2D
## Пуля / метательный предмет. Движение с raycast (без туннелирования).

var level
var vel := Vector2.ZERO
var dmg := 1
var own := true
var col := Color.YELLOW
var max_dist := 400.0
var pierce := 0
var tex := ""
var explode := false
var glass := false
var src
var travelled := 0.0
var hit_ids: Array = []
var spr: Sprite2D

func setup(lv, p: Dictionary) -> void:
	level = lv
	vel = Vector2.from_angle(float(p["ang"])) * float(p["spd"])
	dmg = int(p["dmg"])
	own = bool(p["own"])
	col = p["col"]
	max_dist = float(p["rng"])
	pierce = int(p.get("pierce", 0))
	tex = str(p.get("tex", ""))
	explode = bool(p.get("explode", false))
	glass = bool(p.get("glass", false))
	src = p.get("src", null)
	rotation = vel.angle()
	if tex != "":
		spr = Sprite2D.new()
		spr.texture = Art.weapon_tex(tex)
		spr.scale = Vector2(2, 2)
		add_child(spr)

func _end(pos: Vector2) -> void:
	if explode:
		level.explode(pos, 80.0)
	elif glass:
		Audio.play("glass")
		level.make_noise(pos, 220.0)
	queue_free()

func _physics_process(dt: float) -> void:
	var step := vel * dt
	var mask := 5 if own else 3
	var q := PhysicsRayQueryParameters2D.create(global_position, global_position + step, mask)
	var r := get_world_2d().direct_space_state.intersect_ray(q)
	if not r.is_empty():
		var c = r["collider"]
		if c.has_method("hit") and not hit_ids.has(c.get_instance_id()):
			hit_ids.append(c.get_instance_id())
			c.hit(dmg, vel.normalized(), "throw" if tex != "" else "bullet")
			if own and src and is_instance_valid(src):
				src.stats_hits += 1
			if pierce > 0 and not explode:
				pierce -= 1
				global_position = r["position"] + vel.normalized() * 3.0
				return
			_end(r["position"])
			return
		elif not c.has_method("hit"):
			_end(r["position"])
			return
	global_position += step
	travelled += step.length()
	if spr:
		spr.rotation += dt * 18.0
	if travelled >= max_dist:
		_end(global_position)
		return
	queue_redraw()

func _draw() -> void:
	if tex == "":
		draw_line(Vector2(-12, 0), Vector2.ZERO, Color(col, 0.35), 5.0)
		draw_line(Vector2(-10, 0), Vector2.ZERO, col, 2.0)
