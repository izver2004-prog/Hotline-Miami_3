extends Control
## Сенсорное управление: стик, атака, ближний бой, взаимодействие, подбор, смена, прицел, бег.
## В режиме edit_mode кнопки можно перетаскивать (редактор раскладки).

signal selected_changed(name: String)

const COLORS := {
	"stick": Color(0.0, 0.94, 1.0), "attack": Color(1.0, 0.18, 0.58), "melee": Color(1.0, 0.55, 0.1),
	"interact": Color(0.4, 1.0, 0.4), "pickup": Color(1.0, 0.88, 0.29), "swap": Color(0.7, 0.4, 1.0),
	"aim": Color(0.3, 0.6, 1.0), "run": Color(0.2, 1.0, 0.8),
}
const LABELS := {"attack": "ATK", "melee": "MEL", "interact": "USE", "pickup": "GET", "swap": "SWP", "aim": "AIM", "run": "RUN"}

var edit_mode := false
var selected := ""
var touches := {}
var stick_center := Vector2.ZERO
var stick_active := false
var stick_vec := Vector2.ZERO
var held := {}

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	get_viewport().size_changed.connect(queue_redraw)
	Settings.changed.connect(queue_redraw)

func _exit_tree() -> void:
	Inp.clear_touch()

func _vp() -> Vector2:
	return get_viewport_rect().size

func btn_pos(n: String) -> Vector2:
	var c: Dictionary = Settings.controls[n]
	return Vector2(float(c["x"]) * _vp().x, float(c["y"]) * _vp().y)

func btn_rad(n: String) -> float:
	return float(Settings.controls[n]["size"]) * 0.5

func _input(e: InputEvent) -> void:
	var kind := ""
	var idx := -99
	var pos := Vector2.ZERO
	var down := false
	if e is InputEventScreenTouch:
		kind = "t"
		idx = e.index
		pos = e.position
		down = e.pressed
	elif e is InputEventScreenDrag:
		kind = "d"
		idx = e.index
		pos = e.position
	elif edit_mode and not Inp.use_touch and e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		kind = "t"
		idx = -1
		pos = e.position
		down = e.pressed
	elif edit_mode and not Inp.use_touch and e is InputEventMouseMotion and touches.has(-1):
		kind = "d"
		idx = -1
		pos = e.position
	else:
		return
	if kind == "t":
		if down:
			_down(idx, pos)
		else:
			_up(idx)
	else:
		_move(idx, pos)

func _down(idx: int, pos: Vector2) -> void:
	if edit_mode:
		var best := ""
		for n in Settings.BTN_NAMES:
			if pos.distance_to(btn_pos(n)) <= btn_rad(n):
				best = n
		if best != "":
			selected = best
			touches[idx] = {"k": "drag", "n": best, "off": pos - btn_pos(best)}
			selected_changed.emit(best)
			queue_redraw()
		return
	for n in Settings.BTN_NAMES:
		if n == "stick":
			continue
		if pos.distance_to(btn_pos(n)) <= btn_rad(n) * 1.15:
			touches[idx] = {"k": "btn", "n": n}
			_press(n, true)
			return
	var floating := int(Settings.data["stick_mode"]) == 1
	var zone := float(Settings.data["stick_zone"])
	var on_fixed: bool = pos.distance_to(btn_pos("stick")) <= btn_rad("stick") * 1.4
	if not stick_active and ((not floating and on_fixed) or (floating and pos.x < _vp().x * zone)):
		stick_active = true
		stick_center = pos if floating else btn_pos("stick")
		touches[idx] = {"k": "stick"}
		_move(idx, pos)
		return
	touches[idx] = {"k": "aim"}
	Inp.touch_aim_active = true
	Inp.touch_aim_pos = pos

func _press(n: String, down: bool) -> void:
	match n:
		"attack": Inp.t_attack = down
		"run": Inp.t_run = down
		"aim": Inp.t_aim = down
		_:
			if down:
				Inp.pressed.emit(n)
	if down and Settings.data["vibration"]:
		Input.vibrate_handheld(15)
	held[n] = down
	queue_redraw()

func _move(idx: int, pos: Vector2) -> void:
	if not touches.has(idx):
		return
	var t: Dictionary = touches[idx]
	match t["k"]:
		"drag":
			var np: Vector2 = pos - t["off"]
			var c: Dictionary = Settings.controls[t["n"]]
			c["x"] = clampf(np.x / _vp().x, 0.03, 0.97)
			c["y"] = clampf(np.y / _vp().y, 0.05, 0.95)
			queue_redraw()
		"stick":
			var r := btn_rad("stick")
			var v := pos - stick_center
			if int(Settings.data["stick_mode"]) == 1 and v.length() > r * 1.2:
				stick_center = pos - v.normalized() * r * 1.2
				v = pos - stick_center
			var n := (v / r).limit_length(1.0)
			stick_vec = n
			var m := n * float(Settings.data["stick_sens"])
			Inp.touch_move = Vector2.ZERO if n.length() < 0.12 else m.limit_length(1.0)
			queue_redraw()
		"aim":
			Inp.touch_aim_pos = pos

func _up(idx: int) -> void:
	if not touches.has(idx):
		return
	var t: Dictionary = touches[idx]
	match t["k"]:
		"btn": _press(t["n"], false)
		"stick":
			stick_active = false
			stick_vec = Vector2.ZERO
			Inp.touch_move = Vector2.ZERO
		"aim": Inp.touch_aim_active = false
	touches.erase(idx)
	queue_redraw()

func _draw() -> void:
	var font := ThemeDB.fallback_font
	for n in Settings.BTN_NAMES:
		var c: Dictionary = Settings.controls[n]
		var a := float(c["alpha"])
		var p := btn_pos(n)
		var r := btn_rad(n)
		if n == "stick" and stick_active and int(Settings.data["stick_mode"]) == 1:
			p = stick_center
		var col: Color = COLORS[n]
		draw_circle(p, r, Color(col.r * 0.2, col.g * 0.2, col.b * 0.2, a * 0.8))
		draw_arc(p, r, 0.0, TAU, 40, Color(col, minf(1.0, a + 0.3)), 5.0 if n == selected else 3.0)
		if n == "stick":
			draw_circle(p + stick_vec * r * 0.6, r * 0.38, Color(col, minf(1.0, a + 0.2)))
		else:
			draw_string(font, p + Vector2(-r, r * 0.14), LABELS[n], HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, int(r * 0.45), Color(1, 1, 1, minf(1.0, a + 0.3)))
		if held.get(n, false):
			draw_circle(p, r, Color(col, 0.35))
