extends CanvasLayer
## HUD: очки, комбо, оружие/патроны, оставшиеся враги, пауза, экран смерти и результата.

var level
var score_l: Label
var combo_l: Label
var left_l: Label
var weapon_l: Label
var msg_l: Label
var fps_l: Label
var root: Control
var overlay: Control
var msg_t := 0.0

func setup(lv) -> void:
	level = lv
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	var box := VBoxContainer.new()
	box.position = Vector2(24, 14)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(box)
	score_l = UI.lbl("0", 44, UI.PINK)
	combo_l = UI.lbl("", 30, UI.CYAN)
	left_l = UI.lbl("", 22, UI.YEL)
	for l in [score_l, combo_l, left_l]:
		l.add_theme_constant_override("outline_size", 6)
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
		box.add_child(l)
	weapon_l = UI.lbl("", 26, Color.WHITE)
	weapon_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	weapon_l.add_theme_constant_override("outline_size", 6)
	weapon_l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	var wb := VBoxContainer.new()
	wb.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	wb.offset_left = -330.0
	wb.offset_right = -30.0
	wb.offset_top = 90.0
	wb.offset_bottom = 150.0
	wb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	wb.add_child(weapon_l)
	root.add_child(wb)
	var pb := UI.btn("II", _pause, UI.CYAN, 64.0)
	pb.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	pb.offset_left = -90.0
	pb.offset_right = -26.0
	pb.offset_top = 14.0
	pb.offset_bottom = 78.0
	root.add_child(pb)
	msg_l = UI.lbl("", 40, UI.YEL)
	msg_l.set_anchors_preset(Control.PRESET_CENTER_TOP)
	msg_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_l.offset_left = -450.0
	msg_l.offset_right = 450.0
	msg_l.offset_top = 120.0
	msg_l.add_theme_constant_override("outline_size", 8)
	msg_l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	root.add_child(msg_l)
	fps_l = UI.lbl("", 18, Color.WHITE)
	fps_l.position = Vector2(24, 170)
	root.add_child(fps_l)
	Inp.pressed.connect(func(a):
		if a == "pause":
			_pause())

func message(t: String, secs: float) -> void:
	msg_l.text = t
	msg_t = secs

func popup(text: String, world_pos: Vector2, col: Color) -> void:
	var l := UI.lbl(text, 26, col)
	l.add_theme_constant_override("outline_size", 6)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.position = level.get_viewport().get_canvas_transform() * world_pos
	root.add_child(l)
	var tw := create_tween()
	tw.tween_property(l, "position:y", l.position.y - 60.0, 0.9)
	tw.parallel().tween_property(l, "modulate:a", 0.0, 0.9)
	tw.tween_callback(l.queue_free)

func _process(dt: float) -> void:
	if level == null or not is_instance_valid(level.player):
		return
	score_l.text = "%d" % level.score
	combo_l.text = ("COMBO x%d" % clampi(level.combo, 1, 8)) if level.combo > 1 else ""
	left_l.text = Settings.L("Врагов: %d", "Enemies: %d") % (level.total - level.kills)
	var s: Dictionary = level.player.cur()
	if s["id"] == "":
		weapon_l.text = Settings.L("Кулаки", "Fists")
	else:
		var w: Dictionary = Data.weapon(s["id"])
		var nm: String = w["ru"] if Settings.data["language"] == "ru" else w["en"]
		if w["type"] == "gun":
			weapon_l.text = "%s  %d/%d%s" % [nm, s["ammo"], s["reserve"], "  ..." if level.player.reload_t > 0.0 else ""]
		elif w["type"] == "throw":
			weapon_l.text = "%s  x%d" % [nm, s["ammo"]]
		else:
			weapon_l.text = nm
	if msg_t > 0.0:
		msg_t -= dt
		if msg_t <= 0.0:
			msg_l.text = ""
	fps_l.text = "FPS %d" % Engine.get_frames_per_second() if Settings.data["show_fps"] else ""

func _clear_overlay() -> void:
	if overlay:
		overlay.queue_free()
		overlay = null

func _make_overlay(title: String, col: Color) -> VBoxContainer:
	_clear_overlay()
	overlay = Control.new()
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0, 0, 0, 0.6)
	overlay.add_child(dim)
	var c := CenterContainer.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(c)
	var p := UI.panel(col)
	c.add_child(p)
	var v := VBoxContainer.new()
	v.custom_minimum_size = Vector2(520, 0)
	v.add_theme_constant_override("separation", 10)
	p.add_child(v)
	var t := UI.lbl(title, 44, col)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(t)
	root.add_child(overlay)
	return v

func _pause() -> void:
	if level.state == "dead" or level.state == "done":
		return
	if get_tree().paused:
		get_tree().paused = false
		_clear_overlay()
		return
	get_tree().paused = true
	var v := _make_overlay(Settings.L("ПАУЗА", "PAUSE"), UI.CYAN)
	v.add_child(UI.btn(Settings.L("Продолжить", "Resume"), _pause, UI.CYAN))
	v.add_child(UI.btn(Settings.L("Рестарт", "Restart"), level.restart, UI.PINK))
	v.add_child(UI.btn(Settings.L("В меню", "Menu"), _to_menu, UI.YEL))

func _to_menu() -> void:
	Fx.change_scene("res://scenes/main_menu.tscn")

func show_dead() -> void:
	var v := _make_overlay(Settings.L("ТЫ ПОГИБ", "YOU DIED"), UI.PINK)
	v.add_child(UI.btn(Settings.L("Заново (R)", "Retry (R)"), level.restart, UI.PINK))
	v.add_child(UI.btn(Settings.L("В меню", "Menu"), _to_menu, UI.YEL))

func show_result(res: Dictionary) -> void:
	var rank: String = res["rank"]
	var rc: Color = {"S": UI.YEL, "A": UI.CYAN, "B": UI.CYAN, "C": UI.PINK, "D": UI.PINK}[rank]
	var v := _make_overlay(Settings.L("УРОВЕНЬ ПРОЙДЕН", "LEVEL CLEARED"), rc)
	var rl := UI.lbl(rank, 96, rc)
	rl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(rl)
	v.add_child(UI.lbl(Settings.L("Очки: %d  (бонус времени %d)", "Score: %d  (time bonus %d)") % [res["score"], res["bonus"]], 26))
	v.add_child(UI.lbl(Settings.L("Убито: %d/%d   Время: %.1f с   Точность: %d%%", "Kills: %d/%d   Time: %.1fs   Accuracy: %d%%") % [res["kills"], res["total"], res["time"], int(res["acc"] * 100.0)], 22))
	for id in res.get("unlocked", []):
		v.add_child(UI.lbl(Settings.L("Открыта маска: ", "Mask unlocked: ") + str(Data.mask(id)["ru"]), 26, UI.YEL))
	var nxt := Game.next_level_path()
	if nxt != "":
		v.add_child(UI.btn(Settings.L("Следующий уровень", "Next level"), func(): Game.start_level(nxt), UI.CYAN))
	v.add_child(UI.btn(Settings.L("Заново", "Retry"), level.restart, UI.PINK))
	v.add_child(UI.btn(Settings.L("В меню", "Menu"), _to_menu, UI.YEL))
