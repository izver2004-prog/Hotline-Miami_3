extends Control
## Анимированный неоновый фон меню: циклирующий градиент, перспективная сетка, падающие пиксели.

var t := 0.0
var sq: Array = []

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	for i in 45:
		sq.append([randf(), randf(), randf_range(4.0, 14.0), randf_range(0.02, 0.09), randi() % 3])

func _process(dt: float) -> void:
	t += dt
	queue_redraw()

func _draw() -> void:
	var s := size
	var h := fmod(t * 0.03 + 0.75, 1.0)
	for i in 14:
		draw_rect(Rect2(0, s.y * i / 14.0, s.x, s.y / 14.0 + 1.0), Color.from_hsv(fmod(h + i * 0.012, 1.0), 0.85, 0.07 + 0.012 * i))
	var hor := s.y * 0.58
	for i in range(-14, 15):
		draw_line(Vector2(s.x * 0.5 + i * s.x * 0.012, hor), Vector2(s.x * 0.5 + i * s.x * 0.16, s.y), Color(1.0, 0.18, 0.58, 0.28), 2.0)
	for j in 10:
		var f := fmod(float(j) / 10.0 + t * 0.12, 1.0)
		var y := hor + (s.y - hor) * f * f
		draw_line(Vector2(0, y), Vector2(s.x, y), Color(0.0, 0.94, 1.0, 0.25 * f + 0.05), 2.0)
	var cols := [Color(1.0, 0.18, 0.58), Color(0.0, 0.94, 1.0), Color(1.0, 0.88, 0.29)]
	for q in sq:
		var y2: float = fmod(float(q[1]) + t * float(q[3]), 1.0)
		var sz: float = float(q[2])
		draw_rect(Rect2(float(q[0]) * s.x, y2 * s.y, sz, sz), Color(cols[int(q[4])], 0.35))
